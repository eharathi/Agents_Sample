"""
LLM Configuration Module
"""

import os
from typing import Optional

# Default values
DEFAULT_PROVIDER = "anthropic"
DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5"
DEFAULT_AZURE_OPENAI_API_VERSION = "2024-02-15-preview"

def get_llm_provider() -> str:
    """Get the configured LLM provider."""
    return os.getenv("LLM_PROVIDER", DEFAULT_PROVIDER).lower()

def get_anthropic_api_key() -> Optional[str]:
    """Get the Anthropic API key."""
    return os.getenv("ANTHROPIC_API_KEY")

def get_anthropic_model() -> str:
    """Get the Anthropic model to use."""
    return os.getenv("ANTHROPIC_MODEL", DEFAULT_ANTHROPIC_MODEL)

def get_azure_openai_api_key() -> Optional[str]:
    """Get the Azure OpenAI API key."""
    return os.getenv("AZURE_OPENAI_API_KEY")

def get_azure_openai_endpoint() -> Optional[str]:
    """Get the Azure OpenAI endpoint."""
    return os.getenv("AZURE_OPENAI_ENDPOINT")

def get_azure_openai_api_version() -> str:
    """Get the Azure OpenAI API version."""
    return os.getenv("AZURE_OPENAI_API_VERSION", DEFAULT_AZURE_OPENAI_API_VERSION)

def get_azure_openai_deployment() -> Optional[str]:
    """Get the Azure OpenAI deployment name."""
    return os.getenv("AZURE_OPENAI_DEPLOYMENT")

def validate_configuration() -> None:
    """
    Validate that required configuration is present.
    
    Raises:
        ValueError: If required configuration is missing.
    """
    provider = get_llm_provider()
    
    if provider == "anthropic":
        api_key = get_anthropic_api_key()
        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY environment variable is required when LLM_PROVIDER=anthropic"
            )
            
    elif provider == "azure_openai":
        api_key = get_azure_openai_api_key()
        endpoint = get_azure_openai_endpoint()
        deployment = get_azure_openai_deployment()
        
        if not api_key:
            raise ValueError(
                "AZURE_OPENAI_API_KEY environment variable is required when LLM_PROVIDER=azure_openai"
            )
        if not endpoint:
            raise ValueError(
                "AZURE_OPENAI_ENDPOINT environment variable is required when LLM_PROVIDER=azure_openai"
            )
        if not deployment:
            raise ValueError(
                "AZURE_OPENAI_DEPLOYMENT environment variable is required when LLM_PROVIDER=azure_openai"
            )
            
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}. Supported providers: anthropic, azure_openai")