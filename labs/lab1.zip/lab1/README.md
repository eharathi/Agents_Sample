# Lab 1: Build Your First Python AI Agent

This lab teaches you how to build a minimal AI agent from first principles using Python and an LLM API.

## Duration
60–75 minutes

## Objectives
After completing this lab, you will be able to:
- Explain what makes an LLM application different from a basic chatbot
- Understand the fundamental concept of an AI agent
- Demonstrate how a goal is passed to an LLM
- Show how an LLM can generate a plan
- Explain why structured output is useful for agents
- Implement the first building block of an agent loop in Python
- Separate agent logic from LLM-provider-specific implementation

## Prerequisites
- Python 3.11
- Basic Python knowledge
- Basic REST/API knowledge
- Basic JSON understanding
- Basic Git knowledge
- Access to Claude or Azure OpenAI credentials

## Environment Setup
Create the virtual environment:

```bash
python3.11 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

## Environment Variables

Set these environment variables:
- `LLM_PROVIDER` = `anthropic` or `azure_openai` (default: anthropic)
- `ANTHROPIC_API_KEY` = Your Claude API key
- `ANTHROPIC_MODEL` = Model to use (default: claude-3-haiku-20240307)
- `AZURE_OPENAI_API_KEY` = Your Azure OpenAI API key
- `AZURE_OPENAI_ENDPOINT` = Your Azure OpenAI endpoint
- `AZURE_OPENAI_API_VERSION` = API version (default: 2024-02-15-preview)
- `AZURE_OPENAI_DEPLOYMENT` = Deployment name

## Installation
```bash
pip install -r requirements.txt
```

## Running the Lab
```bash
python main.py
```

## Example
Enter: "Prepare a plan for onboarding a new software engineer."
Output:
```
Goal:
Prepare a plan for onboarding a new software engineer.

Plan:
1. Collect employee information.
2. Verify required documentation.
3. Determine required equipment and software.
4. Create access requests.
5. Schedule orientation.
6. Create an onboarding checklist.
```

## Troubleshooting
- Missing API key: Set the required environment variables
- Incorrect provider: Check LLM_PROVIDER value
- Authentication failure: Verify API keys and permissions
- Timeout: Check network connectivity and API limits