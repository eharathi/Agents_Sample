"""
AI Agent Module
"""

import json
import logging
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from llm_client import LLMClient

logger = logging.getLogger(__name__)

class PlanStep(BaseModel):
    """Represents a single step in the plan."""
    step_number: int = Field(..., description="The step number")
    description: str = Field(..., description="The description of the step")

class Plan(BaseModel):
    """Represents a complete plan."""
    goal: str = Field(..., description="The original goal")
    steps: List[PlanStep] = Field(..., description="List of steps to achieve the goal")

class EnterpriseTaskPlanningAgent:
    """An enterprise task planning agent that creates structured plans from goals."""
    
    def __init__(self, llm_client: LLMClient):
        """
        Initialize the agent with an LLM client.
        
        Args:
            llm_client: An instance of LLMClient to use for generating responses
        """
        self.llm_client = llm_client
        
    def plan_task(self, goal: str) -> Plan:
        """
        Generate a structured plan for a given goal.
        
        Args:
            goal: The task or goal to create a plan for
            
        Returns:
            A Plan object with the goal and structured steps
            
        Raises:
            ValueError: If the generated response doesn't match expected format
            Exception: If LLM generation fails
        """
        # System prompt for the LLM
        system_prompt = (
            "You are an expert enterprise task planning assistant. "
            "Given a goal, you will generate a clear, structured plan with numbered steps. "
            "The plan should be logical and actionable. "
            "Return ONLY the JSON structure with 'goal' and 'steps' fields. "
            "Each step should have a 'step_number' and 'description'. "
            "Do not add any commentary or explanation - only return the JSON structure."
        )
        
        # User prompt
        user_prompt = (
            f"Create a detailed plan for: '{goal}'. "
            "The plan should be well-structured, with 5-10 actionable steps. "
            "Return only the JSON response with the 'goal' and 'steps' fields."
        )
        
        # Create messages for LLM
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            # Generate response from LLM
            response_text = self.llm_client.generate(
                messages=messages,
                temperature=0.2,
                max_tokens=1024
            )
            
            logger.debug("Raw LLM response: %s", response_text)
            
            # Extract JSON from response (handle markdown code blocks)
            json_text = self._extract_json(response_text)
            
            # Parse JSON response
            plan_data = json.loads(json_text)
            
            # Validate and create Plan object
            plan = Plan(**plan_data)
            
            logger.info("Successfully generated plan for goal: %s", goal)
            return plan
            
        except json.JSONDecodeError as e:
            logger.error("Failed to parse JSON response: %s", str(e))
            raise ValueError(f"LLM returned invalid JSON format: {str(e)}")
        except Exception as e:
            logger.error("Plan generation failed: %s", str(e))
            raise Exception(f"Failed to generate plan for goal '{goal}': {str(e)}")
    
    def _extract_json(self, text: str) -> str:
        """
        Extract JSON from text, handling potential markdown code blocks.
        
        Args:
            text: Raw text from LLM
            
        Returns:
            Cleaned JSON string
        """
        # Look for JSON in markdown code blocks
        if text.strip().startswith("```json"):
            # Extract from markdown code block
            end_marker = text.find("```", 7)  # Find the ending markdown marker
            if end_marker != -1:
                json_text = text[7:end_marker].strip()
                return json_text
        
        # If not in markdown code block, assume it's already JSON
        return text.strip()