"""
LLM Client Module - Common interface for different LLM providers
"""

import logging
from typing import Dict, Any, Optional
from llm_config import (
    get_llm_provider,
    get_anthropic_api_key,
    get_anthropic_model,
    get_azure_openai_api_key,
    get_azure_openai_endpoint,
    get_azure_openai_api_version,
    get_azure_openai_deployment,
    validate_configuration
)

logger = logging.getLogger(__name__)

class LLMClient:
    """Common LLM interface for different providers."""
    
    def __init__(self):
        """Initialize the LLM client with appropriate provider."""
        validate_configuration()
        self.provider = get_llm_provider()
        
        if self.provider == "anthropic":
            self._setup_anthropic()
        elif self.provider == "azure_openai":
            self._setup_azure_openai()
        else:
            raise ValueError(f"Unsupported LLM provider: {self.provider}")
    
    def _setup_anthropic(self):
        """Setup Anthropic client."""
        try:
            from anthropic import Anthropic
            self.client = Anthropic(api_key=get_anthropic_api_key())
            self.model = get_anthropic_model()
            logger.info("Initialized Anthropic client with model %s", self.model)
        except ImportError:
            raise ImportError("Anthropic library not installed. Run: pip install anthropic")
    
    def _setup_azure_openai(self):
        """Setup Azure OpenAI client."""
        try:
            from openai import AzureOpenAI
            self.client = AzureOpenAI(
                api_key=get_azure_openai_api_key(),
                api_version=get_azure_openai_api_version(),
                azure_endpoint=get_azure_openai_endpoint()
            )
            self.model = get_azure_openai_deployment()
            logger.info("Initialized Azure OpenAI client with deployment %s", self.model)
        except ImportError:
            raise ImportError("OpenAI library not installed. Run: pip install openai")
    
    def generate(self, messages: list, **kwargs) -> str:
        """
        Generate text from the LLM.
        
        Args:
            messages: List of message dictionaries
            **kwargs: Additional configuration for the call
            
        Returns:
            Generated text response
            
        Raises:
            Exception: If LLM call fails
        """
        try:
            if self.provider == "anthropic":
                # For Anthropic, we need to separate the system message from the rest
                # and pass it as a separate 'system' parameter
                
                # Find and extract system message if it exists
                system_message = None
                filtered_messages = []
                
                for msg in messages:
                    if msg["role"] == "system":
                        system_message = msg["content"]
                    else:
                        filtered_messages.append(msg)
                
                # Prepare kwargs for Anthropic, avoiding duplicate parameters
                anth_kwargs = kwargs.copy()
                anth_kwargs.setdefault('max_tokens', 1024)
                anth_kwargs.setdefault('temperature', 0.2)
                
                # Remove any system parameter from kwargs if it exists to avoid conflicts
                anth_kwargs.pop('system', None)
                
                # Build the call parameters appropriately
                call_params = {
                    "model": self.model,
                    "messages": filtered_messages,
                    **anth_kwargs
                }
                
                # Add system parameter if we found one
                if system_message:
                    call_params["system"] = system_message
                    
                response = self.client.messages.create(**call_params)
                return response.content[0].text
                
            elif self.provider == "azure_openai":
                # Prepare kwargs for Azure OpenAI, avoiding duplicate parameters
                azure_kwargs = kwargs.copy()
                azure_kwargs.setdefault('max_tokens', 1024)
                azure_kwargs.setdefault('temperature', 0.2)
                
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    **azure_kwargs
                )
                return response.choices[0].message.content
                
        except Exception as e:
            logger.error("LLM generation failed: %s", str(e))
            raise Exception(f"Failed to generate response from {self.provider}: {str(e)}")