"""
Main entry point for the Enterprise Task Planning Agent
"""

import logging
import sys
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from agent import EnterpriseTaskPlanningAgent
from llm_client import LLMClient

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

console = Console()

def main():
    """Main entry point for the application."""
    console.print(Panel.fit("[bold blue]Enterprise Task Planning Agent[/bold blue]"))
    console.print("Enter a task or goal to create a structured plan:")
    console.print()
    
    try:
        # Initialize LLM client and agent
        llm_client = LLMClient()
        agent = EnterpriseTaskPlanningAgent(llm_client)
        
        # Get user input
        goal = console.input("[bold yellow]Goal:[/bold yellow] ")
        
        if not goal.strip():
            console.print("[bold red]Error:[/bold red] Goal cannot be empty.")
            sys.exit(1)
        
        # Generate plan
        console.print("[bold cyan]Generating plan...[/bold cyan]")
        plan = agent.plan_task(goal)
        
        # Display results
        console.print()
        console.print(Panel.fit(f"[bold green]Goal:[/bold green]\n{plan.goal}"))
        console.print()
        console.print("[bold green]Plan:[/bold green]")
        
        for step in plan.steps:
            console.print(f"{step.step_number}. {step.description}")
            
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Operation cancelled by user.[/bold yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        logger.error("Application error: %s", str(e))
        sys.exit(1)

if __name__ == "__main__":
    main()