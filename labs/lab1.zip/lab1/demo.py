#!/usr/bin/env python3
"""
Demo script showing the lab functionality
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agent import EnterpriseTaskPlanningAgent
from llm_client import LLMClient

def demo():
    """Demonstrate the agent functionality."""
    print("Lab 1: Build Your First Python AI Agent")
    print("=" * 50)
    
    # Set up configuration to avoid requiring actual API keys for demo
    os.environ.setdefault("LLM_PROVIDER", "anthropic")
    os.environ.setdefault("ANTHROPIC_API_KEY", "demo-key")
    
    try:
        # Verify configuration works
        from llm_config import validate_configuration
        validate_configuration()
        print("✓ Configuration validated")
        
        # Create client and agent
        llm_client = LLMClient()
        agent = EnterpriseTaskPlanningAgent(llm_client)
        
        print("✓ Agent initialized")
        print()
        
        # Show example goal
        goal = "Prepare a plan for onboarding a new software engineer"
        print(f"Goal: {goal}")
        print()
        
        # The actual generation would happen here, but we won't run it
        # because it requires an API key, which we don't have in demo
        print("In a real implementation, this would generate a structured plan.")
        print("The agent would:")
        print("  1. Accept the goal")
        print("  2. Send it to the LLM")  
        print("  3. Ask for a structured plan")
        print("  4. Return a validated plan")
        print()
        print("This demonstrates the core agent architecture - separation of concerns!")
        
    except Exception as e:
        print(f"Demo error: {e}")

if __name__ == "__main__":
    demo()