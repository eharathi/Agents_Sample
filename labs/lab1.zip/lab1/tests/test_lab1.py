"""
Test suite for the Enterprise Task Planning Agent
"""

import unittest
from unittest.mock import Mock, patch
import sys
import os

# Add the current directory to Python path to allow imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")

import json
from pydantic import ValidationError

# Import our modules
from llm_config import validate_configuration
from agent import EnterpriseTaskPlanningAgent, Plan, PlanStep
from llm_client import LLMClient


class TestLLMConfig(unittest.TestCase):
    """Test LLM configuration module."""
    
    def test_validate_configuration_anthropic_valid(self):
        """Test validation with valid Anthropic setup."""
        with patch.dict('os.environ', {
            'LLM_PROVIDER': 'anthropic',
            'ANTHROPIC_API_KEY': 'test-key'
        }):
            # Should not raise exception
            validate_configuration()
    
    def test_validate_configuration_anthropic_missing_key(self):
        """Test validation with missing Anthropic API key."""
        with patch.dict('os.environ', {
            'LLM_PROVIDER': 'anthropic'
        }, clear=True):  # clear=True ensures we start fresh
            # This should raise a ValueError because ANTHROPIC_API_KEY is missing
            with self.assertRaises(ValueError) as context:
                validate_configuration()
            self.assertIn("ANTHROPIC_API_KEY", str(context.exception))
    
    def test_validate_configuration_azure_valid(self):
        """Test validation with valid Azure OpenAI setup."""
        with patch.dict('os.environ', {
            'LLM_PROVIDER': 'azure_openai',
            'AZURE_OPENAI_API_KEY': 'test-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test.openai.azure.com/',
            'AZURE_OPENAI_DEPLOYMENT': 'test-deployment'
        }):
            # Should not raise exception
            validate_configuration()
    
    def test_validate_configuration_azure_missing_key(self):
        """Test validation with missing Azure OpenAI API key."""
        with patch.dict('os.environ', {
            'LLM_PROVIDER': 'azure_openai'
        }, clear=True):  # clear=True ensures we start fresh
            # This should raise a ValueError because required Azure keys are missing
            with self.assertRaises(ValueError) as context:
                validate_configuration()
            self.assertIn("AZURE_OPENAI_API_KEY", str(context.exception))


class TestPlanModel(unittest.TestCase):
    """Test Plan data model."""
    
    def test_plan_creation_valid(self):
        """Test creating a valid Plan."""
        steps = [PlanStep(step_number=1, description="Test step")]
        plan = Plan(goal="Test goal", steps=steps)
        
        self.assertEqual(plan.goal, "Test goal")
        self.assertEqual(len(plan.steps), 1)
        self.assertEqual(plan.steps[0].step_number, 1)
        self.assertEqual(plan.steps[0].description, "Test step")
    
    def test_plan_creation_invalid(self):
        """Test creating an invalid Plan."""
        # Pydantic should validate that goal is required
        try:
            # Missing required fields - this should fail
            Plan(goal="", steps=[])
            # If we reach here, the test should fail
            self.fail("Expected ValidationError was not raised")
        except Exception:
            # Expected behavior - validation should fail
            pass


class TestEnterpriseTaskPlanningAgent(unittest.TestCase):
    """Test the EnterpriseTaskPlanningAgent."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create a mock LLM client
        self.mock_client = Mock()
        self.agent = EnterpriseTaskPlanningAgent(self.mock_client)
    
    def test_extract_json_with_markdown(self):
        """Test extracting JSON from markdown code block."""
        text = "```json\n{\"goal\": \"Test\", \"steps\": []}\n```"
        result = self.agent._extract_json(text)
        self.assertEqual(result, "{\"goal\": \"Test\", \"steps\": []}")
    
    def test_extract_json_without_markdown(self):
        """Test extracting JSON without markdown markers."""
        text = "{\"goal\": \"Test\", \"steps\": []}"
        result = self.agent._extract_json(text)
        self.assertEqual(result, "{\"goal\": \"Test\", \"steps\": []}")
    
    def test_extract_json_partial_markdown(self):
        """Test extracting JSON with partial markdown block."""
        text = "Here's the JSON: ```json\n{\"goal\": \"Test\", \"steps\": []}\n"
        result = self.agent._extract_json(text)
        # Just make sure we get the JSON part, not the whole text
        self.assertIn("\"goal\": \"Test\"", result)


if __name__ == '__main__':
    unittest.main()