#!/usr/bin/env python3
"""
Test to verify the agent works with a fake LLM client (no live API calls)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from llm_client import LLMClient
from agent import EnterpriseWorkflowAgent


class FakeLLMClient(LLMClient):
    """Fake LLM client that simulates the onboarding workflow without API calls."""
    
    def __init__(self):
        self.provider = "fake"
        from llm_client import LLMCallMetrics
        self.metrics = LLMCallMetrics()
        self.step = 0
    
    def generate(self, messages, **kwargs):
        """Simulate the LLM deciding the next action based on workflow state."""
        self.step += 1
        
        # Simulate metrics tracking
        self.metrics.call_count += 1
        self.metrics.total_input_tokens += 150
        self.metrics.total_output_tokens += 50
        self.metrics.total_tokens += 200
        
        # Extract state summary from the last user message
        last_msg = messages[-1].get("content", "") if messages else ""
        
        # Check if we're missing employee info
        if "missing info" in last_msg.lower() and "employee_id" in last_msg.lower():
            return '{"action": "ask_user", "question": "What is the employee ID for the new hire?"}'
        
        # Step 1: We have employee info, validate it
        if self.step == 1:
            return '{"action": "respond", "message": "Employee validation passed. Now determining onboarding requirements..."}'
        
        # Step 2: Check equipment
        elif self.step == 2:
            return '{"action": "tool_call", "tool": "check_equipment_availability", "arguments": {"equipment_type": "laptop"}}'
        
        # Step 3: Check more equipment
        elif self.step == 3:
            return '{"action": "tool_call", "tool": "check_equipment_availability", "arguments": {"equipment_type": "monitor"}}'
        
        # Step 4: Get required access
        elif self.step == 4:
            return '{"action": "tool_call", "tool": "get_required_access", "arguments": {"department": "Data Science", "role": "Senior Data Engineer"}}'
        
        # Step 5: Find induction slots
        elif self.step == 5:
            return '{"action": "tool_call", "tool": "find_induction_slots", "arguments": {"department": "Data Science"}}'
        
        # Step 6: Request approval
        elif self.step == 6:
            return '{"action": "request_approval", "actions": ["Reserve laptop", "Reserve monitor", "Grant software access", "Schedule induction"]}'
        
        # Step 7: Complete
        else:
            return '{"action": "complete", "message": "Onboarding workflow completed successfully!"}'


def test_agent():
    """Test the agent with a fake LLM client."""
    print("Testing Enterprise Workflow Agent...")
    
    try:
        llm_client = FakeLLMClient()
        agent = EnterpriseWorkflowAgent(llm_client)
        print("✅ Agent initialized")
        
        # Start workflow
        workflow_state = agent.start_workflow("EMP-1042")
        print(f"✅ Workflow started for: {workflow_state.employee.name}")
        
        # Process steps until we need approval
        response = agent.process_user_input("")
        print(f"Agent response: {response[:100]}...")
        
        # Continue processing until we need approval
        while "approval required" not in response.lower() and "approve" not in response.lower():
            response = agent.process_user_input("")
            print(f"Agent response: {response[:100]}...")
            if agent.is_workflow_complete():
                break
        
        # Now provide approval
        if not agent.is_workflow_complete():
            response = agent.process_user_input("approve")
            print(f"Agent response after approval: {response[:100]}...")
            
            # Continue processing until completion
            iterations = 0
            while not agent.is_workflow_complete() and iterations < 10:
                response = agent.process_user_input("")
                print(f"Agent response: {response[:100]}...")
                iterations += 1
        
        # Check final state
        if agent.is_workflow_complete():
            final_state = agent.get_workflow_state()
            print(f"✅ Workflow completed with status: {final_state.status.value}")
            if final_state.status.value == "completed":
                print(f"✅ Employee: {final_state.employee.name}")
                print(f"✅ Department: {final_state.employee.department}")
                print(f"✅ Role: {final_state.employee.role}")
                
                # Show some results
                if final_state.welcome_email_draft:
                    print(f"✅ Welcome email generated ({len(final_state.welcome_email_draft)} chars)")
                if final_state.onboarding_checklist:
                    print(f"✅ Onboarding checklist created ({len(final_state.onboarding_checklist)} items)")
                if final_state.executed_actions:
                    print(f"✅ Actions executed: {len(final_state.executed_actions)}")
                
                # Show audit trail snippet
                audit_trail = agent.get_audit_trail()
                if audit_trail:
                    print(f"✅ Audit trail generated ({len(audit_trail)} chars)")
                
                # Show LLM metrics
                metrics = llm_client.get_metrics_summary()
                print(f"✅ LLM calls: {metrics['total_calls']}, Tokens: {metrics['total_tokens']}")
                
                return True
            else:
                print(f"❌ Workflow failed: {final_state.error_message}")
                return False
        else:
            print("⚠️ Workflow not yet complete")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_agent()
    sys.exit(0 if success else 1)
