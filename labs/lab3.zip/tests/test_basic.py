"""
Basic tests for the Employee Onboarding Agent
"""

import os
import sys
import pytest
from unittest.mock import Mock, patch

# Add the parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from state import OnboardingWorkflowState, EmployeeInfo, WorkflowStatus
from tools.employee import get_employee
from tools.equipment import check_equipment_availability
from tools.access import get_required_access
from tools.policy import get_onboarding_policy
from tools.calendar import find_induction_slots
from tools.checklist import create_onboarding_checklist
from tools.email import generate_welcome_email


def test_employee_tool():
    """Test the employee directory tool."""
    # Test existing employee
    employee = get_employee("EMP-1042")
    assert employee.employee_id == "EMP-1042"
    assert employee.name == "Priya Patel"
    assert employee.department == "Data Science"
    
    # Test non-existing employee
    try:
        get_employee("EMP-9999")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass  # Expected


def test_equipment_tool():
    """Test the equipment inventory tool."""
    # Check laptop availability
    laptops = check_equipment_availability("laptop")
    assert len(laptops) > 0
    assert laptops[0].is_available == True
    
    # Check non-existent equipment type
    unknown = check_equipment_availability("unknown")
    assert len(unknown) == 0


def test_access_tool():
    """Test the software/access catalog tool."""
    access = get_required_access("Data Science", "Senior Data Engineer")
    assert len(access) > 0
    # Check that we got SoftwareAccess objects
    assert hasattr(access[0], 'name')
    assert hasattr(access[0], 'access_level')
    assert hasattr(access[0], 'justification')


def test_policy_tool():
    """Test the policy tool."""
    policies = get_onboarding_policy("Onboarding")
    assert len(policies) > 0
    assert policies[0].policy_id == "POL-ONB-001"
    
    specific_policy = get_onboarding_policy()  # Get all
    assert len(specific_policy) >= 5  # We have 5 synthetic policies


def test_calendar_tool():
    """Test the calendar/induction tool."""
    slots = find_induction_slots(department="Data Science")
    assert len(slots) >= 0  # May or may not have Data Science specific slots
    
    virtual_slots = find_induction_slots(virtual_only=True)
    assert len(virtual_slots) > 0  # Should have virtual slots


def test_checklist_tool():
    """Test the checklist generation tool."""
    equipment_needed = [
        {"item_type": "laptop", "description": "MacBook Pro", "item_id": "EQ-001"},
        {"item_type": "monitor", "description": "27\" 4K Monitor", "item_id": "EQ-010"}
    ]
    
    access_needed = [
        {"name": "GitHub Enterprise", "access_level": "Write", "justification": "Code access"},
        {"name": "AWS Console", "access_level": "Admin", "justification": "Cloud access"}
    ]
    
    induction_session = {
        "session_id": "IND-001",
        "title": "New Employee Welcome",
        "scheduled_time": "2026-10-02T10:00:00",
        "duration_minutes": 90,
        "location": "Virtual",
        "instructor": "HR Team"
    }
    
    checklist = create_onboarding_checklist(
        employee_name="Test Employee",
        department="Engineering",
        role="Software Engineer",
        equipment_needed=equipment_needed,
        software_access_needed=access_needed,
        induction_session=induction_session
    )
    
    assert len(checklist) > 0
    # Check that we got OnboardingChecklistItem objects
    assert hasattr(checklist[0], 'item_id')
    assert hasattr(checklist[0], 'description')
    assert hasattr(checklist[0], 'category')


def test_email_tool():
    """Test the welcome email generation tool."""
    equipment_list = [
        {"item_type": "laptop", "description": "MacBook Pro", "item_id": "EQ-001"}
    ]
    
    access_list = [
        {"name": "GitHub Enterprise", "access_level": "Write", "justification": "Code access"}
    ]
    
    email = generate_welcome_email(
        employee_name="Test Employee",
        department="Engineering",
        role="Software Engineer",
        manager_name="Manager Name",
        start_date="2026-10-02",
        equipment_list=equipment_list,
        access_list=access_list
    )
    
    assert "Test Employee" in email
    assert "Engineering" in email
    assert "Software Engineer" in email
    assert "Welcome to the Team" in email


def test_state_management():
    """Test the workflow state management."""
    state = OnboardingWorkflowState()
    assert state.workflow_id.startswith("onboard_")
    assert state.status == WorkflowStatus.INITIALIZED
    
    # Test adding to conversation
    state.add_to_conversation("user", "Hello")
    assert len(state.conversation_history) == 1
    assert state.conversation_history[0]["role"] == "user"
    assert state.conversation_history[0]["content"] == "Hello"
    
    # Test updating status
    state.update_status(WorkflowStatus.COLLECTING_INFO)
    assert state.status == WorkflowStatus.COLLECTING_INFO


if __name__ == "__main__":
    test_employee_tool()
    test_equipment_tool()
    test_access_tool()
    test_policy_tool()
    test_calendar_tool()
    test_checklist_tool()
    test_email_tool()
    test_state_management()
    print("✅ All tests passed!")