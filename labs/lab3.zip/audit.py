"""
Audit Trail Module - Records workflow events for observability
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field
from state import OnboardingWorkflowState
import logging

logger = logging.getLogger(__name__)


class AuditEvent(BaseModel):
    """Audit event model."""
    timestamp: datetime = Field(default_factory=datetime.now)
    event_type: str = Field(..., description="Type of event")
    description: str = Field(..., description="Event description")
    workflow_id: str = Field(..., description="Workflow identifier")
    details: Dict[str, Any] = Field(default_factory=dict, description="Additional event details")


class AuditTrail:
    """Manages audit trail for workflow execution."""
    
    def __init__(self, workflow_state: OnboardingWorkflowState):
        """
        Initialize audit trail for a workflow.
        
        Args:
            workflow_state: The workflow state to audit
        """
        self.workflow_state = workflow_state
        self.events: List[AuditEvent] = []
    
    def record_event(self, event_type: str, description: str, details: Optional[Dict[str, Any]] = None) -> None:
        """
        Record an audit event.
        
        Args:
            event_type: Type of event (e.g., WORKFLOW_STARTED, TOOL_EXECUTED)
            description: Human-readable description of the event
            details: Optional additional details
        """
        event = AuditEvent(
            event_type=event_type,
            description=description,
            workflow_id=self.workflow_state.workflow_id,
            details=details or {}
        )
        self.events.append(event)
        logger.info("AUDIT: %s - %s", event_type, description)
    
    def get_events(self) -> List[AuditEvent]:
        """
        Get all audit events.
        
        Returns:
            List of audit events in chronological order
        """
        return self.events
    
    def get_events_by_type(self, event_type: str) -> List[AuditEvent]:
        """
        Get events of a specific type.
        
        Args:
            event_type: Type of events to retrieve
            
        Returns:
            List of matching audit events
        """
        return [event for event in self.events if event.event_type == event_type]
    
    def format_audit_trail(self) -> str:
        """
        Format the audit trail as a readable string.
        
        Returns:
            Formatted audit trail
        """
        if not self.events:
            return "No audit events recorded."
        
        lines = [f"Audit Trail for Workflow: {self.workflow_state.workflow_id}"]
        lines.append("=" * 50)
        
        for event in self.events:
            time_str = event.timestamp.strftime("%H:%M:%S")
            details_str = ""
            if event.details:
                details_str = f" | {event.details}"
            
            lines.append(f"[{time_str}] {event.event_type}: {event.description}{details_str}")
        
        return "\n".join(lines)