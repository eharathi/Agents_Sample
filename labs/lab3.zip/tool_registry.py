"""
Tool Registry Module - Manages tool registration and schema generation
"""

from typing import Dict, Any, Callable, Optional, List
from pydantic import BaseModel, Field
import json
import logging

logger = logging.getLogger(__name__)


class ToolDefinition(BaseModel):
    """Definition of a tool that can be used by the agent."""
    name: str = Field(..., description="Unique name of the tool")
    description: str = Field(..., description="Description of what the tool does")
    parameters: Dict[str, Any] = Field(..., description="JSON schema for tool parameters")
    is_write_operation: bool = Field(False, description="Whether this tool performs write/modification operations")


class ToolRegistry:
    """Registry for managing available tools."""
    
    def __init__(self):
        """Initialize an empty tool registry."""
        self._tools: Dict[str, Callable] = {}
        self._tool_definitions: Dict[str, ToolDefinition] = {}
    
    def register_tool(self, func: Callable, definition: ToolDefinition) -> None:
        """
        Register a tool with the registry.
        
        Args:
            func: The function that implements the tool
            definition: The tool definition including metadata and schema
        """
        self._tools[definition.name] = func
        self._tool_definitions[definition.name] = definition
        logger.info("Registered tool: %s", definition.name)
    
    def get_tool(self, name: str) -> Optional[Callable]:
        """
        Get a tool function by name.
        
        Args:
            name: Name of the tool to retrieve
            
        Returns:
            The tool function if found, None otherwise
        """
        return self._tools.get(name)
    
    def get_tool_definition(self, name: str) -> Optional[ToolDefinition]:
        """
        Get a tool definition by name.
        
        Args:
            name: Name of the tool definition to retrieve
            
        Returns:
            The tool definition if found, None otherwise
        """
        return self._tool_definitions.get(name)
    
    def tool_exists(self, name: str) -> bool:
        """
        Check if a tool exists in the registry.
        
        Args:
            name: Name of the tool to check
            
        Returns:
            True if tool exists, False otherwise
        """
        return name in self._tools
    
    def get_all_schemas(self) -> List[Dict[str, Any]]:
        """
        Get schemas for all registered tools.
        
        Returns:
            List of tool schemas in the format expected by LLMs
        """
        schemas = []
        for definition in self._tool_definitions.values():
            schema = {
                "type": "function",
                "function": {
                    "name": definition.name,
                    "description": definition.description,
                    "parameters": definition.parameters
                }
            }
            schemas.append(schema)
        return schemas
    
    def get_read_only_tools(self) -> List[str]:
        """
        Get names of all read-only tools.
        
        Returns:
            List of read-only tool names
        """
        return [
            name for name, definition in self._tool_definitions.items()
            if not definition.is_write_operation
        ]
    
    def get_write_tools(self) -> List[str]:
        """
        Get names of all write/modification tools.
        
        Returns:
            List of write tool names
        """
        return [
            name for name, definition in self._tool_definitions.items()
            if definition.is_write_operation
        ]


# Global tool registry instance
tool_registry = ToolRegistry()


def _register_default_tools():
    """Register all default enterprise tools with the registry."""
    from tools.employee import get_employee, create_employee
    from tools.equipment import check_equipment_availability, reserve_equipment, release_equipment
    from tools.access import get_required_access
    from tools.policy import get_onboarding_policy, get_policy_by_id
    from tools.calendar import find_induction_slots, schedule_induction
    from tools.checklist import create_onboarding_checklist
    from tools.email import generate_welcome_email

    # Read-only tools
    tool_registry.register_tool(
        get_employee,
        ToolDefinition(
            name="get_employee",
            description="Retrieve employee information from the enterprise employee directory",
            parameters={
                "type": "object",
                "properties": {
                    "employee_id": {"type": "string", "description": "Employee identifier (e.g., 'EMP-1042')"}
                },
                "required": ["employee_id"]
            },
            is_write_operation=False
        )
    )

    tool_registry.register_tool(
        check_equipment_availability,
        ToolDefinition(
            name="check_equipment_availability",
            description="Check availability of equipment by type",
            parameters={
                "type": "object",
                "properties": {
                    "equipment_type": {"type": "string", "description": "Type of equipment (e.g., 'laptop', 'monitor')"}
                },
                "required": ["equipment_type"]
            },
            is_write_operation=False
        )
    )

    tool_registry.register_tool(
        get_required_access,
        ToolDefinition(
            name="get_required_access",
            description="Determine required software and access based on department and role",
            parameters={
                "type": "object",
                "properties": {
                    "department": {"type": "string", "description": "Employee's department"},
                    "role": {"type": "string", "description": "Employee's job role"}
                },
                "required": ["department", "role"]
            },
            is_write_operation=False
        )
    )

    tool_registry.register_tool(
        get_onboarding_policy,
        ToolDefinition(
            name="get_onboarding_policy",
            description="Retrieve onboarding policies, optionally filtered by category",
            parameters={
                "type": "object",
                "properties": {
                    "policy_category": {"type": "string", "description": "Category to filter by (e.g., 'Onboarding', 'Security')"}
                }
            },
            is_write_operation=False
        )
    )

    tool_registry.register_tool(
        find_induction_slots,
        ToolDefinition(
            name="find_induction_slots",
            description="Find available induction sessions based on criteria",
            parameters={
                "type": "object",
                "properties": {
                    "department": {"type": "string", "description": "Filter for department-specific sessions"},
                    "preferred_date": {"type": "string", "description": "Preferred date in YYYY-MM-DD format"},
                    "virtual_only": {"type": "boolean", "description": "Only show virtual sessions"}
                }
            },
            is_write_operation=False
        )
    )

    # Write tools
    tool_registry.register_tool(
        reserve_equipment,
        ToolDefinition(
            name="reserve_equipment",
            description="Reserve a specific piece of equipment for an employee",
            parameters={
                "type": "object",
                "properties": {
                    "item_id": {"type": "string", "description": "Equipment identifier (e.g., 'EQ-001')"},
                    "employee_id": {"type": "string", "description": "Employee identifier to reserve for"}
                },
                "required": ["item_id", "employee_id"]
            },
            is_write_operation=True
        )
    )

    tool_registry.register_tool(
        schedule_induction,
        ToolDefinition(
            name="schedule_induction",
            description="Schedule an employee for an induction session",
            parameters={
                "type": "object",
                "properties": {
                    "session_id": {"type": "string", "description": "Induction session identifier"},
                    "employee_id": {"type": "string", "description": "Employee identifier"},
                    "employee_name": {"type": "string", "description": "Employee name for tracking"}
                },
                "required": ["session_id", "employee_id", "employee_name"]
            },
            is_write_operation=True
        )
    )

    tool_registry.register_tool(
        create_onboarding_checklist,
        ToolDefinition(
            name="create_onboarding_checklist",
            description="Create a comprehensive onboarding checklist based on employee requirements",
            parameters={
                "type": "object",
                "properties": {
                    "employee_name": {"type": "string", "description": "Name of the employee"},
                    "department": {"type": "string", "description": "Employee's department"},
                    "role": {"type": "string", "description": "Employee's job role"},
                    "equipment_needed": {"type": "array", "items": {"type": "object"}, "description": "List of equipment requirements"},
                    "software_access_needed": {"type": "array", "items": {"type": "object"}, "description": "List of software/access requirements"},
                    "induction_session": {"type": "object", "description": "Scheduled induction session info"}
                },
                "required": ["employee_name", "department", "role", "equipment_needed", "software_access_needed"]
            },
            is_write_operation=True
        )
    )

    tool_registry.register_tool(
        generate_welcome_email,
        ToolDefinition(
            name="generate_welcome_email",
            description="Generate a draft welcome email for a new employee",
            parameters={
                "type": "object",
                "properties": {
                    "employee_name": {"type": "string", "description": "Name of the new employee"},
                    "department": {"type": "string", "description": "Employee's department"},
                    "role": {"type": "string", "description": "Employee's job role"},
                    "manager_name": {"type": "string", "description": "Manager's name"},
                    "start_date": {"type": "string", "description": "Start date (YYYY-MM-DD)"},
                    "equipment_list": {"type": "array", "items": {"type": "object"}, "description": "List of equipment to be provided"},
                    "access_list": {"type": "array", "items": {"type": "object"}, "description": "List of system access to be granted"},
                    "induction_session": {"type": "object", "description": "Scheduled induction session"}
                },
                "required": ["employee_name", "department", "role", "manager_name", "start_date", "equipment_list", "access_list"]
            },
            is_write_operation=True
        )
    )

    logger.info("Registered %d default tools", len(tool_registry._tools))


# Auto-register tools on import
_register_default_tools()
