"""
Software/Access Catalog Tool - Determines required access based on role and department
"""

from typing import List, Dict, Any
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class SoftwareAccess(BaseModel):
    """Software/access requirement model."""
    name: str = Field(..., description="Software/system name")
    access_level: str = Field(..., description="Access level required (e.g., Read, Write, Admin)")
    justification: str = Field(..., description="Why this access is needed for the role")


# Load synthetic access catalog from JSON file
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def _load_access_catalog() -> dict:
    """Load access catalog data from JSON file."""
    path = os.path.join(_DATA_DIR, "access_catalog.json")
    with open(path, "r") as f:
        raw = json.load(f)
    # Convert string keys "Department|Role" to tuple keys
    catalog = {}
    for key, value in raw.items():
        if key == "default":
            catalog["default"] = value
        else:
            dept, role = key.split("|", 1)
            catalog[(dept, role)] = value
    return catalog

SYNTHETIC_ACCESS_CATALOG = _load_access_catalog()


def get_required_access(department: str, role: str) -> List[SoftwareAccess]:
    """
    Determine required software and access based on department and role.
    
    Args:
        department: Employee's department
        role: Employee's job role
        
    Returns:
        List of required software/access items
    """
    logger.info(f"Determining required access for {department}/{role}")
    
    # Normalize inputs
    department = department.strip().title()
    role = role.strip()
    
    # Look up specific role/department combination
    key = (department, role)
    if key in SYNTHETIC_ACCESS_CATALOG:
        access_list = SYNTHETIC_ACCESS_CATALOG[key]
    else:
        # Fall back to department-only lookup
        dept_keys = [(dept, r) for (dept, r) in SYNTHETIC_ACCESS_CATALOG.keys() if dept == department]
        if dept_keys:
            # Use the first matching department key
            access_list = SYNTHETIC_ACCESS_CATALOG[dept_keys[0]]
        else:
            # Use default access
            access_list = SYNTHETIC_ACCESS_CATALOG["default"]
    
    # Convert to SoftwareAccess objects
    return [SoftwareAccess(**access) for access in access_list]


def get_access_catalog_info() -> Dict[str, Any]:
    """
    Get information about the access catalog for debugging/reference.
    
    Returns:
        Dictionary containing catalog statistics and sample entries
    """
    total_combinations = len(SYNTHETIC_ACCESS_CATALOG) - 1  # Subtract 1 for default
    total_default_items = len(SYNTHETIC_ACCESS_CATALOG["default"])
    
    return {
        "total_role_department_combinations": total_combinations,
        "default_access_items": total_default_items,
        "sample_combinations": list(SYNTHETIC_ACCESS_CATALOG.keys())[:5]
    }