"""
Equipment Inventory Tool - Manages equipment availability and reservations
"""

from typing import List, Optional
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class EquipmentItem(BaseModel):
    """Equipment item model."""
    item_id: str = Field(..., description="Equipment identifier")
    item_type: str = Field(..., description="Type of equipment")
    description: str = Field(..., description="Equipment description")
    is_available: bool = Field(True, description="Whether equipment is available")
    reserved_for: Optional[str] = Field(None, description="Employee ID if reserved")
    location: str = Field(..., description="Physical location of equipment")


# Load synthetic equipment data from JSON file
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def _load_equipment() -> list:
    """Load equipment data from JSON file."""
    path = os.path.join(_DATA_DIR, "equipment.json")
    with open(path, "r") as f:
        return json.load(f)

SYNTHETIC_EQUIPMENT = _load_equipment()


def check_equipment_availability(equipment_type: str) -> List[EquipmentItem]:
    """
    Check availability of equipment by type.
    
    Args:
        equipment_type: Type of equipment to check (e.g., 'laptop', 'monitor')
        
    Returns:
        List of available equipment items
    """
    logger.info(f"Checking availability for equipment type: {equipment_type}")
    
    equipment_type = equipment_type.lower().strip()
    available_items = []
    
    for equip_data in SYNTHETIC_EQUIPMENT:
        if equip_data["item_type"] == equipment_type and equip_data["is_available"]:
            equipment = EquipmentItem(**equip_data)
            available_items.append(equipment)
    
    return available_items


def reserve_equipment(item_id: str, employee_id: str) -> EquipmentItem:
    """
    Reserve a specific piece of equipment for an employee.
    
    Args:
        item_id: Equipment identifier (e.g., 'EQ-001')
        employee_id: Employee identifier to reserve for
        
    Returns:
        Updated equipment item with reservation info
        
    Raises:
        ValueError: If equipment not found or not available
    """
    logger.info(f"Reserving equipment {item_id} for employee {employee_id}")
    
    # Normalize employee ID
    employee_id = employee_id.strip().upper()
    if not employee_id.startswith("EMP-"):
        employee_id = f"EMP-{employee_id}"
    
    # Find the equipment
    for equip_data in SYNTHETIC_EQUIPMENT:
        if equip_data["item_id"] == item_id:
            if not equip_data["is_available"]:
                raise ValueError(f"Equipment {item_id} is not available (currently reserved for {equip_data.get('reserved_for')})")
            
            # Reserve the equipment
            equip_data["is_available"] = False
            equip_data["reserved_for"] = employee_id
            
            equipment = EquipmentItem(**equip_data)
            logger.info(f"Successfully reserved {item_id} for {employee_id}")
            return equipment
    
    raise ValueError(f"Equipment '{item_id}' not found in inventory")


def release_equipment(item_id: str) -> EquipmentItem:
    """
    Release a reserved piece of equipment back to inventory.
    
    Args:
        item_id: Equipment identifier to release
        
    Returns:
        Updated equipment item with availability restored
        
    Raises:
        ValueError: If equipment not found
    """
    logger.info(f"Releasing equipment {item_id}")
    
    for equip_data in SYNTHETIC_EQUIPMENT:
        if equip_data["item_id"] == item_id:
            if equip_data["is_available"]:
                raise ValueError(f"Equipment {item_id} is already available")
            
            # Release the equipment
            equip_data["is_available"] = True
            equip_data["reserved_for"] = None
            
            equipment = EquipmentItem(**equip_data)
            logger.info(f"Successfully released {item_id}")
            return equipment
    
    raise ValueError(f"Equipment '{item_id}' not found in inventory")