"""
Checklist Generation Tool - Creates onboarding checklists
"""

from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class OnboardingChecklistItem(BaseModel):
    """Onboarding checklist item model."""
    item_id: str = Field(..., description="Checklist item identifier")
    description: str = Field(..., description="Task description")
    category: str = Field(..., description="Category (e.g., Equipment, Access, Training, HR)")
    completed: bool = Field(False, description="Whether item is completed")
    assigned_to: Optional[str] = Field(None, description="Person responsible for completion")
    due_date: Optional[str] = Field(None, description="Due date (ISO format)")
    priority: str = Field(default="medium", description="Priority level: low, medium, high")


def create_onboarding_checklist(
    employee_name: str,
    department: str,
    role: str,
    equipment_needed: List[dict],
    software_access_needed: List[dict],
    induction_session: Optional[dict] = None
) -> List[OnboardingChecklistItem]:
    """
    Create a comprehensive onboarding checklist based on employee requirements.
    
    Args:
        employee_name: Name of the employee being onboarded
        department: Employee's department
        role: Employee's job role
        equipment_needed: List of equipment requirements
        software_access_needed: List of software/access requirements
        induction_session: Scheduled induction session info (optional)
        
    Returns:
        List of onboarding checklist items
    """
    logger.info(f"Creating onboarding checklist for {employee_name} ({department}/{role})")
    
    checklist_items = []
    item_counter = 1
    
    # HR/Admin Tasks
    checklist_items.append(OnboardingChecklistItem(
        item_id=f"CHK-{item_counter:03d}",
        description=f"Complete new hire paperwork for {employee_name}",
        category="HR",
        assigned_to="HR Coordinator",
        due_date=(datetime.now() + timedelta(days=1)).isoformat(),
        priority="high"
    ))
    item_counter += 1
    
    checklist_items.append(OnboardingChecklistItem(
        item_id=f"CHK-{item_counter:03d}",
        description=f"Set up payroll and benefits for {employee_name}",
        category="HR",
        assigned_to="HR Specialist",
        due_date=(datetime.now() + timedelta(days=2)).isoformat(),
        priority="high"
    ))
    item_counter += 1
    
    # Equipment Tasks
    for equip in equipment_needed:
        checklist_items.append(OnboardingChecklistItem(
            item_id=f"CHK-{item_counter:03d}",
            description=f"Prepare and configure {equip.get('description', equip.get('item_type', 'equipment'))} for {employee_name}",
            category="Equipment",
            assigned_to="IT Support",
            due_date=(datetime.now() + timedelta(days=3)).isoformat(),
            priority="high"
        ))
        item_counter += 1
    
    # Access/Software Tasks
    for access in software_access_needed:
        checklist_items.append(OnboardingChecklistItem(
            item_id=f"CHK-{item_counter:03d}",
            description=f"Set up {access.get('name', 'system')} access ({access.get('access_level', 'standard')}) for {employee_name}",
            category="Access",
            assigned_to="IT Security",
            due_date=(datetime.now() + timedelta(days=2)).isoformat(),
            priority="high"
        ))
        item_counter += 1
    
    # Training Tasks
    checklist_items.append(OnboardingChecklistItem(
        item_id=f"CHK-{item_counter:03d}",
        description=f"Complete mandatory security training for {employee_name}",
        category="Training",
        assigned_to="Employee",
        due_date=(datetime.now() + timedelta(days=5)).isoformat(),
        priority="high"
    ))
    item_counter += 1
    
    if induction_session:
        checklist_items.append(OnboardingChecklistItem(
            item_id=f"CHK-{item_counter:03d}",
            description=f"Attend induction session: {induction_session.get('title', 'New Employee Orientation')} for {employee_name}",
            category="Training",
            assigned_to="Employee",
            due_date=induction_session.get('scheduled_time', (datetime.now() + timedelta(days=4)).isoformat()),
            priority="high"
        ))
        item_counter += 1
    
    # Department-specific tasks
    dept_specific_tasks = {
        "Engineering": [
            ("Set up development environment", "Tool installation and configuration"),
            ("Access code repositories", "GitHub/GitLab repository access"),
            ("Join team introduction meeting", "Meet with team members and manager")
        ],
        "Data Science": [
            ("Access data warehouse", "SQL/Snowflake access credentials"),
            ("Set up analytics environment", "Python/R/Jupyter setup"),
            ("Attend data team standup", "Introduction to data team processes")
        ],
        "Marketing": [
            ("Access marketing platforms", "HubSpot, Google Analytics, social media accounts"),
            ("Review brand guidelines", "Brand and messaging guidelines"),
            ("Meet with campaign team", "Introduction to current marketing initiatives")
        ],
        "Sales": [
            ("Access CRM system", "Salesforce setup and territory assignment"),
            ("Review product catalog", "Product and service offerings training"),
            ("Shadow senior sales rep", "Field observation and mentorship")
        ],
        "HR": [
            ("Access HRIS system", "Workday/BambooHR navigation training"),
            ("Review employee handbook", "Company policies and procedures"),
            ("Attend new hire orientation", "Company-wide orientation session")
        ]
    }
    
    if department in dept_specific_tasks:
        for description, assigned_to in dept_specific_tasks[department]:
            checklist_items.append(OnboardingChecklistItem(
                item_id=f"CHK-{item_counter:03d}",
                description=f"{description} for {employee_name}",
                category="Department Training",
                assigned_to=assigned_to,
                due_date=(datetime.now() + timedelta(days=4)).isoformat(),
                priority="medium"
            ))
            item_counter += 1
    
    # Final Tasks
    checklist_items.append(OnboardingChecklistItem(
        item_id=f"CHK-{item_counter:03d}",
        description=f"First day orientation and workspace setup for {employee_name}",
        category="Orientation",
        assigned_to="Manager",
        due_date=(datetime.now() + timedelta(days=5)).isoformat(),
        priority="high"
    ))
    item_counter += 1
    
    checklist_items.append(OnboardingChecklistItem(
        item_id=f"CHK-{item_counter:03d}",
        description=f"30-day check-in meeting for {employee_name}",
        category="Follow-up",
        assigned_to="Manager",
        due_date=(datetime.now() + timedelta(days=35)).isoformat(),
        priority="medium"
    ))
    item_counter += 1
    
    logger.info(f"Created checklist with {len(checklist_items)} items for {employee_name}")
    return checklist_items


def get_checklist_by_category(checklist: List[OnboardingChecklistItem], category: str) -> List[OnboardingChecklistItem]:
    """
    Filter checklist items by category.
    
    Args:
        checklist: Full checklist
        category: Category to filter by
        
    Returns:
        List of checklist items in the specified category
    """
    return [item for item in checklist if item.category.lower() == category.lower()]


def get_completion_percentage(checklist: List[OnboardingChecklistItem]) -> float:
    """
    Calculate the percentage of completed checklist items.
    
    Args:
        checklist: List of checklist items
        
    Returns:
        Completion percentage (0-100)
    """
    if not checklist:
        return 0.0
    
    completed_count = sum(1 for item in checklist if item.completed)
    return (completed_count / len(checklist)) * 100