"""
Calendar/Induction Tool - Manages induction session scheduling
"""

from typing import List, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class InductionSession(BaseModel):
    """Induction session model."""
    session_id: str = Field(..., description="Session identifier")
    title: str = Field(..., description="Session title")
    scheduled_time: str = Field(..., description="Scheduled time (ISO format)")
    duration_minutes: int = Field(..., description="Duration in minutes")
    location: str = Field(..., description="Location (virtual or physical)")
    instructor: str = Field(..., description="Instructor name")
    capacity: int = Field(..., description="Maximum number of attendees")
    current_attendees: int = Field(default=0, description="Current number of attendees")
    is_virtual: bool = Field(True, description="Whether session is virtual")


# Load synthetic induction calendar from JSON file
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def _load_calendar() -> list:
    """Load induction calendar data from JSON file."""
    path = os.path.join(_DATA_DIR, "calendar.json")
    with open(path, "r") as f:
        return json.load(f)

SYNTHETIC_INDUCTION_CALENDAR = _load_calendar()


def find_induction_slots(
    department: Optional[str] = None,
    preferred_date: Optional[str] = None,
    virtual_only: bool = False
) -> List[InductionSession]:
    """
    Find available induction sessions based on criteria.
    
    Args:
        department: Filter for department-specific sessions
        preferred_date: Preferred date in YYYY-MM-DD format
        virtual_only: Only show virtual sessions if True
        
    Returns:
        List of available induction sessions with capacity remaining
    """
    logger.info(f"Finding induction slots - Dept: {department}, Date: {preferred_date}, Virtual: {virtual_only}")
    
    available_sessions = []
    
    for session_data in SYNTHETIC_INDUCTION_CALENDAR:
        # Check if session has available capacity
        if session_data["current_attendees"] >= session_data["capacity"]:
            continue
        
        # Apply filters
        if virtual_only and not session_data["is_virtual"]:
            continue
        
        if department:
            session_title = session_data["title"].lower()
            dept_keywords = {
                "engineering": ["engineering", "software", "development", "tech"],
                "data science": ["data", "analytics", "science"],
                "marketing": ["marketing", "brand", "campaign"],
                "sales": ["sales", "account", "revenue"],
                "hr": ["hr", "human resources", "benefits"]
            }
            
            if department.lower() in dept_keywords:
                keywords = dept_keywords[department.lower()]
                if not any(keyword in session_title for keyword in keywords):
                    # Skip non-department-specific sessions unless it's a general onboarding
                    if "welcome" not in session_title and "security" not in session_title and "benefits" not in session_title:
                        continue
        
        if preferred_date:
            session_date = session_data["scheduled_time"].split("T")[0]
            if session_date != preferred_date:
                continue
        
        # Convert to InductionSession object
        session = InductionSession(**session_data)
        available_sessions.append(session)
    
    # Sort by scheduled time (earliest first)
    available_sessions.sort(key=lambda x: x.scheduled_time)
    
    return available_sessions


def schedule_induction(
    session_id: str,
    employee_id: str,
    employee_name: str
) -> InductionSession:
    """
    Schedule an employee for an induction session.
    
    Args:
        session_id: Induction session identifier
        employee_id: Employee identifier
        employee_name: Employee name for tracking
        
    Returns:
        Updated induction session with attendee count increased
        
    Raises:
        ValueError: If session not found or at capacity
    """
    logger.info(f"Scheduling employee {employee_name} ({employee_id}) for induction session {session_id}")
    
    # Find the session
    for session_data in SYNTHETIC_INDUCTION_CALENDAR:
        if session_data["session_id"] == session_id:
            # Check capacity
            if session_data["current_attendees"] >= session_data["capacity"]:
                raise ValueError(f"Induction session {session_id} is at full capacity")
            
            # Add attendee
            session_data["current_attendees"] += 1
            
            session = InductionSession(**session_data)
            logger.info(f"Successfully scheduled {employee_name} for session {session_id}")
            return session
    
    raise ValueError(f"Induction session '{session_id}' not found")


def get_induction_session_details(session_id: str) -> Optional[InductionSession]:
    """
    Get details for a specific induction session.
    
    Args:
        session_id: Session identifier
        
    Returns:
        Induction session details if found, None otherwise
    """
    logger.info(f"Getting details for induction session: {session_id}")
    
    for session_data in SYNTHETIC_INDUCTION_CALENDAR:
        if session_data["session_id"] == session_id:
            return InductionSession(**session_data)
    
    return None