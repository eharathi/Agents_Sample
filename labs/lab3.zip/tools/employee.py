"""
Employee Directory Tool - Manages employee information
"""

from typing import Optional
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class Employee(BaseModel):
    """Employee information model."""
    employee_id: str = Field(..., description="Unique employee identifier")
    name: str = Field(..., description="Employee full name")
    department: str = Field(..., description="Department the employee works in")
    role: str = Field(..., description="Job role")
    location: str = Field(..., description="Office location")
    manager: str = Field(..., description="Direct manager name")
    employment_status: str = Field(..., description="Current employment status")
    start_date: str = Field(..., description="Expected start date")


# Load synthetic employee data from JSON file
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def _load_employees() -> list:
    """Load employee data from JSON file."""
    path = os.path.join(_DATA_DIR, "employees.json")
    with open(path, "r") as f:
        return json.load(f)

SYNTHETIC_EMPLOYEES = _load_employees()


def get_employee(employee_id: str) -> Employee:
    """
    Retrieve employee information from the enterprise employee directory.
    
    Args:
        employee_id: Employee identifier (e.g., 'EMP-1042')
        
    Returns:
        Employee information
        
    Raises:
        ValueError: If employee not found
    """
    logger.info(f"Looking up employee: {employee_id}")
    
    # Normalize the employee ID format
    employee_id = employee_id.strip().upper()
    if not employee_id.startswith("EMP-"):
        employee_id = f"EMP-{employee_id}"
    
    for emp_data in SYNTHETIC_EMPLOYEES:
        if emp_data["employee_id"] == employee_id:
            return Employee(**emp_data)
    
    raise ValueError(f"Employee '{employee_id}' not found in directory")


def create_employee(
    employee_id: str,
    name: str,
    department: str,
    role: str,
    location: str,
    manager: str,
    start_date: str
) -> Employee:
    """
    Create a new employee record (simulated).
    
    Args:
        employee_id: Employee identifier
        name: Employee full name
        department: Department name
        role: Job role
        location: Office location
        manager: Manager name
        start_date: Start date
        
    Returns:
        Created employee information
    """
    logger.info(f"Creating employee record for: {name} ({employee_id})")
    
    employee = Employee(
        employee_id=employee_id,
        name=name,
        department=department,
        role=role,
        location=location,
        manager=manager,
        employment_status="Active",
        start_date=start_date
    )
    
    # In a real system, this would save to a database
    # For this simulation, we just return the created object
    return employee