"""
Welcome Email Generation Tool - Creates draft welcome emails
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class EmailTemplate(BaseModel):
    """Email template model."""
    template_id: str = Field(..., description="Template identifier")
    subject: str = Field(..., description="Email subject line")
    body: str = Field(..., description="Email body content")
    is_html: bool = Field(False, description="Whether email is HTML formatted")


def generate_welcome_email(
    employee_name: str,
    department: str,
    role: str,
    manager_name: str,
    start_date: str,
    equipment_list: List[Dict[str, Any]],
    access_list: List[Dict[str, Any]],
    induction_session: Optional[Dict[str, Any]] = None
) -> str:
    """
    Generate a draft welcome email for a new employee.
    
    Args:
        employee_name: Name of the new employee
        department: Employee's department
        role: Employee's job role
        manager_name: Manager's name
        start_date: Start date (YYYY-MM-DD format)
        equipment_list: List of equipment to be provided
        access_list: List of system access to be granted
        induction_session: Scheduled induction session (optional)
        
    Returns:
        Draft email content (plain text)
    """
    logger.info(f"Generating welcome email for {employee_name}")
    
    # Format equipment list
    equipment_text = ""
    if equipment_list:
        equipment_items = [eq.get('description', eq.get('item_type', 'equipment')) for eq in equipment_list]
        equipment_text = "\n".join([f"• {item}" for item in equipment_items])
    else:
        equipment_text = "• Standard equipment package (to be determined)"
    
    # Format access list
    access_text = ""
    if access_list:
        access_items = [f"{acc.get('name', 'System')} ({acc.get('access_level', 'access')})" for acc in access_list]
        access_text = "\n".join([f"• {item}" for item in access_items])
    else:
        access_text = "• Standard access package (to be determined)"
    
    # Format induction info
    induction_text = ""
    if induction_session:
        induction_text = f"You are scheduled to attend the induction session: '{induction_session.get('title', 'New Employee Orientation')}' on {induction_session.get('scheduled_time', 'TBD')}."
    else:
        induction_text = "Your induction session will be scheduled separately by the HR team."
    
    # Generate email content
    email_content = f"""Subject: Welcome to the Team, {employee_name}!

Dear {employee_name},

Welcome to [Company Name]! We are excited to have you join our team as a {role} in the {department} department.

Your employment is scheduled to begin on {start_date}. Below are the details of your onboarding arrangements:

EQUIPMENT TO BE PROVIDED:
{equipment_text}

SYSTEM ACCESS TO BE GRANTED:
{access_text}

INDUCTION AND TRAINING:
{induction_text}

Your manager, {manager_name}, will be your primary point of contact during your onboarding process. They will reach out to you prior to your start date to confirm details and answer any questions you may have.

Please find attached:
- New hire paperwork (to be completed before your start date)
- Benefits enrollment information
- Company policies and procedures overview

We recommend reviewing the attached materials prior to your first day to ensure a smooth onboarding experience.

If you have any questions before your start date, please don't hesitate to reach out to your manager or the HR team at hr@company.com.

Welcome aboard!

Best regards,
[Company Name] HR Team
hr@company.com
"""

    return email_content


def generate_welcome_email_html(
    employee_name: str,
    department: str,
    role: str,
    manager_name: str,
    start_date: str,
    equipment_list: List[Dict[str, Any]],
    access_list: List[Dict[str, Any]],
    induction_session: Optional[Dict[str, Any]] = None
) -> str:
    """
    Generate an HTML version of the welcome email.
    
    Args:
        Same as generate_welcome_email
        
    Returns:
        HTML formatted email content
    """
    logger.info(f"Generating HTML welcome email for {employee_name}")
    
    # Format equipment list
    equipment_items = ""
    if equipment_list:
        for eq in equipment_list:
            equipment_items += f"<li>{eq.get('description', eq.get('item_type', 'equipment'))}</li>"
    else:
        equipment_items = "<li>Standard equipment package (to be determined)</li>"
    
    # Format access list
    access_items = ""
    if access_list:
        for acc in access_list:
            access_items += f"<li>{acc.get('name', 'System')} ({acc.get('access_level', 'access')})</li>"
    else:
        access_items = "<li>Standard access package (to be determined)</li>"
    
    # Format induction info
    induction_text = ""
    if induction_session:
        induction_text = f"<p>You are scheduled to attend the induction session: '<strong>{induction_session.get('title', 'New Employee Orientation')}</strong>' on <strong>{induction_session.get('scheduled_time', 'TBD')}</strong>.</p>"
    else:
        induction_text = "<p>Your induction session will be scheduled separately by the HR team.</p>"
    
    # Generate HTML email content
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome to the Team, {employee_name}!</title>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background-color: #0066cc; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }}
        .content {{ background-color: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }}
        .section {{ margin-bottom: 25px; }}
        .section-title {{ color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 5px; margin-bottom: 15px; }}
        ul {{ padding-left: 20px; }}
        li {{ margin-bottom: 8px; }}
        .footer {{ text-align: center; margin-top: 30px; font-size: 0.9em; color: #666; }}
        .button {{ display: inline-block; background-color: #0066cc; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; margin: 10px 0; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome to the Team, {employee_name}!</h1>
    </div>
    <div class="content">
        <p>Dear {employee_name},</p>
        
        <p>Welcome to [Company Name]! We are excited to have you join our team as a <strong>{role}</strong> in the <strong>{department}</strong> department.</p>
        
        <p>Your employment is scheduled to begin on <strong>{start_date}</strong>. Below are the details of your onboarding arrangements:</p>
        
        <div class="section">
            <h2 class="section-title">Equipment to be Provided</h2>
            <ul>{equipment_items}</ul>
        </div>
        
        <div class="section">
            <h2 class="section-title">System Access to be Granted</h2>
            <ul>{access_items}</ul>
        </div>
        
        <div class="section">
            <h2 class="section-title">Induction and Training</h2>
            {induction_text}
        </div>
        
        <p>Your manager, <strong>{manager_name}</strong>, will be your primary point of contact during your onboarding process. They will reach out to you prior to your start date to confirm details and answer any questions you may have.</p>
        
        <p>Please find attached:</p>
        <ul>
            <li>New hire paperwork (to be completed before your start date)</li>
            <li>Benefits enrollment information</li>
            <li>Company policies and procedures overview</li>
        </ul>
        
        <p>We recommend reviewing the attached materials prior to your first day to ensure a smooth onboarding experience.</p>
        
        <p>If you have any questions before your start date, please don't hesitate to reach out to your manager or the HR team at <a href="mailto:hr@company.com">hr@company.com</a>.</p>
        
        <p>Welcome aboard!</p>
    </div>
    <div class="footer">
        <p>Best regards,<br>
        [Company Name] HR Team<br>
        <a href="mailto:hr@company.com">hr@company.com</a></p>
    </div>
</body>
</html>"""
    
    return html_content