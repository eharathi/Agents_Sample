"""
Policy Tool - Retrieves relevant onboarding policies
"""

from typing import List, Optional
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class Policy(BaseModel):
    """Policy information model."""
    policy_id: str = Field(..., description="Unique policy identifier")
    title: str = Field(..., description="Policy title")
    category: str = Field(..., description="Policy category")
    content: str = Field(..., description="Detailed policy content")
    effective_date: str = Field(..., description="Effective date of policy")
    version: str = Field(..., description="Policy version")


# Load synthetic policy data from JSON file
import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def _load_policies() -> list:
    """Load policy data from JSON file."""
    path = os.path.join(_DATA_DIR, "policies.json")
    with open(path, "r") as f:
        return json.load(f)

SYNTHETIC_POLICIES = _load_policies()


def get_onboarding_policy(policy_category: Optional[str] = None) -> List[Policy]:
    """
    Retrieve onboarding policies, optionally filtered by category.
    
    Args:
        policy_category: Optional category to filter by (e.g., 'Onboarding', 'Security')
        
    Returns:
        List of matching policies
    """
    logger.info(f"Retrieving onboarding policies" + (f" for category: {policy_category}" if policy_category else ""))
    
    if policy_category:
        filtered_policies = [
            policy for policy in SYNTHETIC_POLICIES 
            if policy["category"].lower() == policy_category.lower()
        ]
        return [Policy(**policy) for policy in filtered_policies]
    else:
        return [Policy(**policy) for policy in SYNTHETIC_POLICIES]


def get_policy_by_id(policy_id: str) -> Optional[Policy]:
    """
    Retrieve a specific policy by its ID.
    
    Args:
        policy_id: Policy identifier (e.g., 'POL-ONB-001')
        
    Returns:
        Policy if found, None otherwise
    """
    logger.info(f"Retrieving policy: {policy_id}")
    
    for policy_data in SYNTHETIC_POLICIES:
        if policy_data["policy_id"] == policy_id:
            return Policy(**policy_data)
    
    return None