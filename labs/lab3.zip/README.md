# Lab 3: Autonomous Enterprise Workflow Agent — Employee Onboarding Agent

**Duration:** 120–150 minutes  
**Prerequisites:** Lab 1 (Reasoning/Planning Agent), Lab 2 (Tool-Calling Agent)

---

## Overview

Build an autonomous AI agent that executes a complete employee onboarding workflow. The agent maintains context, uses multiple enterprise tools, validates information, handles failures, and requires human approval before consequential actions.

```
Lab 1: LLM + Goal + Plan
        ↓
Lab 2: LLM + Tools + Tool Calling
        ↓
Lab 3: LLM + Tools + Memory + State
              + Workflow + Guardrails
              + Human Approval + Audit Trail
```

---

## Learning Objectives

By the end of this lab, you will be able to:

1. Design an explicit workflow state machine for multi-step business processes
2. Maintain conversation memory and workflow state separately
3. Register and classify tools as read-only vs. write operations
4. Implement deterministic validation and guardrails in Python
5. Build a human-in-the-loop approval gate for protected actions
6. Create an audit trail for observability and compliance
7. Handle failures gracefully and recover when possible
8. Prevent duplicate actions with idempotency checks
9. Track LLM token usage and estimated costs

---

## Architecture

```
lab3/
├── agent.py              # LLM-driven workflow orchestrator
├── state.py              # Pydantic workflow state models
├── llm_client.py         # Common LLM interface (Claude / Azure OpenAI)
├── llm_config.py         # Provider configuration from env vars
├── tool_registry.py      # Tool registration and schema management
├── guardrails.py         # Safety constraints and validation
├── audit.py              # Audit trail management
├── main.py               # CLI entry point
├── requirements.txt      # Python dependencies
├── .gitignore
│
├── tools/                # Enterprise tool implementations
│   ├── employee.py       # Employee directory
│   ├── equipment.py      # Equipment inventory
│   ├── access.py         # Software/access catalog
│   ├── policy.py         # Policy retrieval
│   ├── calendar.py       # Induction scheduling
│   ├── checklist.py      # Checklist generation
│   └── email.py          # Welcome email generation
│
├── data/                 # Synthetic enterprise data (JSON)
│   ├── employees.json
│   ├── equipment.json
│   ├── access_catalog.json
│   ├── policies.json
│   └── calendar.json
│
└── tests/                # Automated tests (no live LLM required)
    ├── test_basic.py
    └── test_agent.py
```

---

## Environment Setup

### 1. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure environment variables

The lab supports two LLM providers. Choose one:

**Option A: Anthropic (Claude) — default**
```bash
export LLM_PROVIDER=anthropic
export ANTHROPIC_API_KEY="your-api-key-here"
# Optional overrides
export ANTHROPIC_MODEL="claude-haiku-4-5"
export ANTHROPIC_TEMPERATURE="0.2"
export ANTHROPIC_MAX_TOKENS="1024"
```

**Option B: Azure OpenAI**
```bash
export LLM_PROVIDER=azure_openai
export AZURE_OPENAI_API_KEY="your-api-key-here"
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="your-deployment-name"
# Optional overrides
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
export AZURE_OPENAI_TEMPERATURE="0.2"
export AZURE_OPENAI_MAX_TOKENS="1024"
```

**Global settings**
```bash
export LLM_TIMEOUT="30"           # Request timeout in seconds
export LLM_MAX_RETRIES="3"        # Max retry attempts on failure
export MAX_AGENT_ITERATIONS="15"  # Max workflow loop iterations
```

---

## Running the Lab

### Running the agent

```bash
python main.py
```

You can either:
- Provide an employee ID directly (e.g., `EMP-1042`)
- Press Enter to start interactively and answer the agent's questions

### Running tests

Tests use a fake LLM client (no API key required):

```bash
cd tests
python -m pytest test_basic.py test_agent.py -v
```

---

## The Workflow

```
Employee Request
       │
       ▼
Collect Information ←──→ Ask User (if missing)
       │
       ▼
Validate Information
       │
       ▼
Determine Requirements
       │
       ├── Employee Directory (get_employee)
       ├── Equipment Inventory (check_equipment_availability)
       ├── Software Catalog (get_required_access)
       └── Calendar (find_induction_slots)
       │
       ▼
Build Onboarding Plan
       │
       ▼
Human Approval ←── Reject → Terminate
       │
       ▼
Execute Approved Actions
       │
       ├── reserve_equipment (WRITE)
       ├── schedule_induction (WRITE)
       ├── create_onboarding_checklist (WRITE)
       └── generate_welcome_email (WRITE)
       │
       ▼
Final Summary + Audit Trail
```

---

## Tools

| Tool | Type | Description |
|------|------|-------------|
| `get_employee` | Read | Look up employee by ID |
| `check_equipment_availability` | Read | Check equipment stock |
| `get_required_access` | Read | Get required software access |
| `get_onboarding_policy` | Read | Retrieve policies |
| `find_induction_slots` | Read | Find available induction sessions |
| `reserve_equipment` | Write | Reserve equipment for employee |
| `schedule_induction` | Write | Book an induction session |
| `create_onboarding_checklist` | Write | Generate onboarding checklist |
| `generate_welcome_email` | Write | Create welcome email draft |

Write tools are blocked until explicit human approval is granted.

---

## Guardrails

1. **No write without approval** — `guardrail_no_write_without_approval`
2. **Employee validation** — `validate_employee_exists`
3. **Equipment validation** — `guardrail_validate_equipment_requested`
4. **Duplicate prevention** — `guardrail_prevent_duplicate_actions`
5. **No arbitrary tools** — Only registered tools in `tool_registry` can execute
6. **Max iterations** — `MAX_AGENT_ITERATIONS` prevents infinite loops

---

## Exercises

### Exercise 1 — Define Workflow State
Open `state.py`. Identify the Pydantic models. Add a new field to `OnboardingWorkflowState` (e.g., `priority: str`) and observe how it affects validation.

### Exercise 2 — Add Conversation Memory
In `agent.py`, locate `_build_context()`. Modify it to include only the last 5 conversation turns instead of 10. Observe how context size changes.

### Exercise 3 — Connect Multiple Tools
In `tool_registry.py`, add a new read-only tool (e.g., `get_it_policy`). Register it and verify it appears in `get_all_schemas()`.

### Exercise 4 — Implement the Workflow Loop
Trace through `_run_agent_loop()` in `agent.py`. Add a `print()` statement to log each iteration number and action type.

### Exercise 5 — Add Validation
In `guardrails.py`, add a new validation: check that the employee's `start_date` is in the future. Reject the workflow if it's not.

### Exercise 6 — Add Guardrails
Modify `guardrail_validate_equipment_requested` to also check that `equipment.is_available` is `True` before allowing the workflow to proceed.

### Exercise 7 — Add Human Approval
Run `python main.py`. When prompted for approval, type `reject`. Observe how the workflow terminates cleanly.

### Exercise 8 — Add Audit Logging
In `agent.py`, add an audit event every time a tool is executed. Use `self.state.add_to_conversation("audit", f"Tool executed: {tool_name}")`.

### Exercise 9 — Handle Failure and Recovery
In `tools/equipment.py`, temporarily modify `check_equipment_availability` to return an empty list for `"laptop"`. Run the workflow and observe how the agent handles the missing equipment.

### Exercise 10 — Complete End-to-End Workflow
Run `main.py` with a real API key. Complete the full onboarding for `EMP-1042`. Verify:
- Equipment is reserved
- Access is granted
- Induction is scheduled
- Checklist is generated
- Welcome email is drafted
- Audit trail is complete

---

## Example Output

```
🚀 Employee Onboarding Agent
========================================
✅ Agent initialized successfully

📋 Starting onboarding workflow...
Employee ID (or press Enter to skip): EMP-1042
✅ Started workflow for employee: Priya Patel

🔄 Processing workflow...

Agent: Employee validation passed. Now determining onboarding requirements...

Agent: APPROVAL REQUIRED
Employee: Priya Patel (EMP-1042)
Department: Data Science

Proposed actions:
  1. Reserve laptop (MacBook Pro 14-inch M3 Pro) for Priya Patel
  2. Grant Write access to GitHub Enterprise for Priya Patel
  3. Schedule induction: New Employee Welcome & Company Overview

Approve these actions? [y/n]: y

Agent: Onboarding workflow completed!
Employee: Priya Patel (EMP-1042)
Status: completed
Checklist items: 19
Executed actions: Reserve EQ-001, Grant Write access to GitHub Enterprise, ...
Welcome email draft: Available

📊 WORKFLOW COMPLETED
==================================================
Status: completed
Employee: Priya Patel (EMP-1042)
Department: Data Science
Role: Senior Data Engineer

📈 LLM METRICS:
  total_calls: 6
  total_tokens: 1200
  estimated_total_cost_usd: 0.0012
```

---

## Failure Scenarios

### Missing Employee
```bash
# Try an invalid employee ID
python main.py
# Enter: EMP-9999
# Expected: Agent reports employee not found and asks for a valid ID
```

### Equipment Unavailable
Modify `data/equipment.json` to set all laptops `"is_available": false`. Run the workflow. The agent should report the failure and skip laptop reservation.

### Rejected Approval
Run `python main.py` and type `reject` when asked for approval. The workflow should terminate with status `failed`.

### LLM Timeout
Set `LLM_TIMEOUT=1` and run with a slow connection. The agent should retry up to `LLM_MAX_RETRIES` times, then fail gracefully.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Ensure you're running from the `lab3/` directory or have installed the package |
| `ANTHROPIC_API_KEY not found` | Export the environment variable before running |
| `Azure OpenAI endpoint missing` | Set `AZURE_OPENAI_ENDPOINT` to your resource URL |
| Tests fail with import errors | Run `cd tests && python -m pytest` from the `lab3/` root |
| Agent loops infinitely | Check `MAX_AGENT_ITERATIONS` is set; default is 15 |
| Write operations blocked | Ensure you typed `approve` or `y` when prompted |

---

## Security Principle

> **The LLM proposes actions; Python determines whether those actions are valid and authorized.**

The LLM never directly executes code. It can only suggest tool calls. The Python runtime:
1. Validates the tool exists in the registry
2. Checks if it's a write operation
3. Verifies human approval is granted
4. Prevents duplicate actions
5. Executes the tool and updates state

---

## Next Steps

- Lab 4: Multi-agent orchestration and delegation
- Lab 5: RAG and long-term memory
- Lab 6: Production deployment and monitoring
