"""
LLM Configuration Module - Extended for Lab 3
"""

import os
from typing import Optional

# Default values
DEFAULT_PROVIDER = "anthropic"
DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5"
DEFAULT_AZURE_OPENAI_API_VERSION = "2024-02-15-preview"
DEFAULT_MAX_TOKENS = 1024
DEFAULT_TEMPERATURE = 0.2
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3
DEFAULT_AZURE_OPENAI_TEMPERATURE = 0.2
DEFAULT_AZURE_OPENAI_MAX_TOKENS = 1024

def get_llm_provider() -> str:
    """Get the configured LLM provider."""
    return os.getenv("LLM_PROVIDER", DEFAULT_PROVIDER).lower()

def get_anthropic_api_key() -> Optional[str]:
    """Get the Anthropic API key."""
    return os.getenv("ANTHROPIC_API_KEY")

def get_anthropic_model() -> str:
    """Get the Anthropic model."""
    return os.getenv("ANTHROPIC_MODEL", DEFAULT_ANTHROPIC_MODEL)

def get_anthropic_temperature() -> float:
    """Get the Anthropic temperature."""
    try:
        return float(os.getenv("ANTHROPIC_TEMPERATURE", DEFAULT_TEMPERATURE))
    except ValueError:
        return DEFAULT_TEMPERATURE

def get_anthropic_max_tokens() -> int:
    """Get the Anthropic max tokens."""
    try:
        return int(os.getenv("ANTHROPIC_MAX_TOKENS", DEFAULT_MAX_TOKENS))
    except ValueError:
        return DEFAULT_MAX_TOKENS

def get_azure_openai_api_key() -> Optional[str]:
    """Get the Azure OpenAI API key."""
    return os.getenv("AZURE_OPENAI_API_KEY")

def get_azure_openai_endpoint() -> Optional[str]:
    """Get the Azure OpenAI endpoint."""
    return os.getenv("AZURE_OPENAI_ENDPOINT")

def get_azure_openai_api_version() -> str:
    """Get the Azure OpenAI API version."""
    return os.getenv("AZURE_OPENAI_API_VERSION", DEFAULT_AZURE_OPENAI_API_VERSION)

def get_azure_openai_deployment() -> Optional[str]:
    """Get the Azure OpenAI deployment name."""
    return os.getenv("AZURE_OPENAI_DEPLOYMENT")

def get_azure_openai_temperature() -> float:
    """Get the Azure OpenAI temperature."""
    try:
        return float(os.getenv("AZURE_OPENAI_TEMPERATURE", DEFAULT_AZURE_OPENAI_TEMPERATURE))
    except ValueError:
        return DEFAULT_AZURE_OPENAI_TEMPERATURE

def get_azure_openai_max_tokens() -> int:
    """Get the Azure OpenAI max tokens."""
    try:
        return int(os.getenv("AZURE_OPENAI_MAX_TOKENS", DEFAULT_AZURE_OPENAI_MAX_TOKENS))
    except ValueError:
        return DEFAULT_AZURE_OPENAI_MAX_TOKENS

def get_llm_timeout() -> int:
    """Get the LLM request timeout in seconds."""
    try:
        return int(os.getenv("LLM_TIMEOUT", DEFAULT_TIMEOUT))
    except ValueError:
        return DEFAULT_TIMEOUT

def get_llm_max_retries() -> int:
    """Get the maximum number of LLM request retries."""
    try:
        return int(os.getenv("LLM_MAX_RETRIES", DEFAULT_MAX_RETRIES))
    except ValueError:
        return DEFAULT_MAX_RETRIES

def get_max_agent_iterations() -> int:
    """Get the maximum number of agent workflow iterations."""
    try:
        return int(os.getenv("MAX_AGENT_ITERATIONS", "15"))
    except ValueError:
        return 15

def get_log_file() -> Optional[str]:
    """Get the log file path. Returns None if logging to file is disabled."""
    return os.getenv("LOG_FILE", "logs/agent.log")

def get_log_level() -> str:
    """Get the logging level."""
    return os.getenv("LOG_LEVEL", "INFO").upper()

def validate_configuration() -> None:
    """Validate that required configuration is present."""
    provider = get_llm_provider()
    
    if provider == "anthropic":
        if not get_anthropic_api_key():
            raise ValueError("ANTHROPIC_API_KEY environment variable is required for Anthropic provider")
    elif provider == "azure_openai":
        if not get_azure_openai_api_key():
            raise ValueError("AZURE_OPENAI_API_KEY environment variable is required for Azure OpenAI provider")
        if not get_azure_openai_endpoint():
            raise ValueError("AZURE_OPENAI_ENDPOINT environment variable is required for Azure OpenAI provider")
        if not get_azure_openai_deployment():
            raise ValueError("AZURE_OPENAI_DEPLOYMENT environment variable is required for Azure OpenAI provider")
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}. Supported providers are: anthropic, azure_openai")