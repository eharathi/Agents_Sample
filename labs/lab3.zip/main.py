#!/usr/bin/env python3
"""
Command-line interface for the Employee Onboarding Agent
"""

import sys
from agent import EnterpriseWorkflowAgent
from llm_client import LLMClient
from logging_config import setup_logging


def main():
    """Main CLI entry point."""
    # Setup logging first
    log_file = setup_logging()
    if log_file:
        print(f"📝 Logging to: {log_file}")
    
    print("🚀 Employee Onboarding Agent")
    print("=" * 40)
    
    # Initialize LLM client and agent
    try:
        llm_client = LLMClient()
        agent = EnterpriseWorkflowAgent(llm_client)
        print("✅ Agent initialized successfully")
    except Exception as e:
        print(f"❌ Failed to initialize agent: {e}")
        sys.exit(1)
    
    # Start workflow - either with an employee ID or interactively
    print("\n📋 Starting onboarding workflow...")
    print("You can provide an employee ID (e.g., EMP-1042) or leave blank to start interactively.")
    employee_input = input("Employee ID (or press Enter to skip): ").strip()
    
    try:
        if employee_input:
            workflow_state = agent.start_workflow(employee_input)
            print(f"✅ Started workflow for employee: {workflow_state.employee.name or 'Unknown'}")
        else:
            workflow_state = agent.start_workflow()
            print("✅ Started interactive onboarding workflow")
    except Exception as e:
        print(f"❌ Failed to start workflow: {e}")
        sys.exit(1)
    
    # Main interaction loop
    print("\n🔄 Processing workflow...")
    response = ""
    
    while not agent.is_workflow_complete():
        # Get agent response
        if not response:
            response = agent.process_user_input("")
            print(f"\nAgent: {response}")
            continue
        
        # Check if we need user input
        if agent.get_workflow_state().status.value == "awaiting_approval":
            user_input = input("\nYour response [y/n]: ").strip()
            response = agent.process_user_input(user_input)
            print(f"\nAgent: {response}")
        elif agent.get_workflow_state().status.value == "requires_user_input":
            user_input = input("\nYour answer: ").strip()
            response = agent.process_user_input(user_input)
            print(f"\nAgent: {response}")
        elif "?" in response and len(response) < 500:
            # Agent asked a question
            user_input = input("\nYour answer: ").strip()
            response = agent.process_user_input(user_input)
            print(f"\nAgent: {response}")
        else:
            # Automatic progression
            response = agent.process_user_input("")
            print(f"\nAgent: {response}")
    
    # Show final results
    print("\n" + "=" * 50)
    print("📊 WORKFLOW COMPLETED")
    print("=" * 50)
    
    final_state = agent.get_workflow_state()
    if final_state:
        print(f"Status: {final_state.status.value}")
        print(f"Employee: {final_state.employee.name} ({final_state.employee.employee_id})")
        print(f"Department: {final_state.employee.department}")
        print(f"Role: {final_state.employee.role}")
        
        if final_state.welcome_email_draft:
            print("\n📧 Welcome Email Draft Generated:")
            print("-" * 30)
            print(final_state.welcome_email_draft[:500] + "..." if len(final_state.welcome_email_draft) > 500 else final_state.welcome_email_draft)
        
        if final_state.onboarding_checklist:
            print(f"\n📋 Onboarding Checklist: {len(final_state.onboarding_checklist)} items")
            for item in final_state.onboarding_checklist[:3]:
                status = "✓" if item.completed else "○"
                print(f"  {status} {item.description} ({item.category})")
            if len(final_state.onboarding_checklist) > 3:
                print(f"  ... and {len(final_state.onboarding_checklist) - 3} more items")
    
    # Show audit trail
    audit_trail = agent.get_audit_trail()
    if audit_trail:
        print("\n📋 AUDIT TRAIL:")
        print("-" * 30)
        print(audit_trail)
    
    # Show LLM metrics
    metrics = llm_client.get_metrics_summary()
    print("\n📈 LLM METRICS:")
    print("-" * 30)
    for key, value in metrics.items():
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
