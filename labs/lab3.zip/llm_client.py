"""
LLM Client Module - Common interface for different LLM providers (Production Version)
"""

import logging
import time
from typing import Dict, Any, Optional, List
from llm_config import (
    get_llm_provider,
    get_anthropic_api_key,
    get_anthropic_model,
    get_anthropic_max_tokens,
    get_azure_openai_api_key,
    get_azure_openai_endpoint,
    get_azure_openai_api_version,
    get_azure_openai_deployment,
    get_azure_openai_temperature,
    get_azure_openai_max_tokens,
    get_llm_timeout,
    get_llm_max_retries,
    validate_configuration
)

logger = logging.getLogger(__name__)


class LLMCallMetrics:
    """Tracks metrics for a single LLM call."""
    
    def __init__(self):
        self.call_count = 0
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_tokens = 0
        self.total_cost = 0.0
        self.call_history: List[Dict[str, Any]] = []
    
    def record_call(self, input_tokens: int, output_tokens: int, model: str, latency: float):
        """Record metrics from an LLM call."""
        self.call_count += 1
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.total_tokens += input_tokens + output_tokens
        
        # Estimate cost (simplified - real pricing varies by model)
        cost = self._estimate_cost(input_tokens, output_tokens, model)
        self.total_cost += cost
        
        self.call_history.append({
            "call_number": self.call_count,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "model": model,
            "latency_seconds": latency,
            "estimated_cost_usd": cost
        })
        
        # Log the call metrics
        logger.info(
            "LLM Call #%d | Model: %s | Input: %d tokens | Output: %d tokens | Total: %d tokens | Latency: %.2fs | Est. Cost: $%.6f",
            self.call_count, model, input_tokens, output_tokens, input_tokens + output_tokens, latency, cost
        )
    
    def _estimate_cost(self, input_tokens: int, output_tokens: int, model: str) -> float:
        """Estimate cost in USD based on model and tokens."""
        # Simplified pricing (per 1K tokens)
        pricing = {
            "claude-haiku": {"input": 0.00025, "output": 0.00125},
            "claude-sonnet": {"input": 0.003, "output": 0.015},
            "claude-opus": {"input": 0.015, "output": 0.075},
            "gpt-4": {"input": 0.03, "output": 0.06},
            "gpt-4o": {"input": 0.005, "output": 0.015},
            "gpt-3.5": {"input": 0.0005, "output": 0.0015},
        }
        
        model_lower = model.lower()
        for key, prices in pricing.items():
            if key in model_lower:
                input_cost = (input_tokens / 1000) * prices["input"]
                output_cost = (output_tokens / 1000) * prices["output"]
                return input_cost + output_cost
        
        # Default fallback
        return (input_tokens / 1000) * 0.001 + (output_tokens / 1000) * 0.002
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of all LLM call metrics."""
        return {
            "total_calls": self.call_count,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_tokens,
            "estimated_total_cost_usd": round(self.total_cost, 6),
            "average_tokens_per_call": round(self.total_tokens / max(self.call_count, 1), 2),
            "average_latency_seconds": round(
                sum(c["latency_seconds"] for c in self.call_history) / max(len(self.call_history), 1), 3
            )
        }


class LLMClient:
    """Common LLM interface for different providers."""
    
    def __init__(self):
        """Initialize the LLM client with appropriate provider."""
        validate_configuration()
        self.provider = get_llm_provider()
        self.metrics = LLMCallMetrics()
        self.timeout = get_llm_timeout()
        self.max_retries = get_llm_max_retries()
        
        if self.provider == "anthropic":
            self._setup_anthropic()
        elif self.provider == "azure_openai":
            self._setup_azure_openai()
        else:
            raise ValueError(f"Unsupported LLM provider: {self.provider}")
    
    def _setup_anthropic(self):
        """Setup Anthropic client."""
        try:
            from anthropic import Anthropic
            self.client = Anthropic(api_key=get_anthropic_api_key())
            self.model = get_anthropic_model()
            logger.info("Initialized Anthropic client with model %s", self.model)
        except ImportError:
            raise ImportError("Anthropic library not installed. Run: pip install anthropic")
    
    def _setup_azure_openai(self):
        """Setup Azure OpenAI client."""
        try:
            from openai import AzureOpenAI
            self.client = AzureOpenAI(
                api_key=get_azure_openai_api_key(),
                api_version=get_azure_openai_api_version(),
                azure_endpoint=get_azure_openai_endpoint()
            )
            self.model = get_azure_openai_deployment()
            logger.info("Initialized Azure OpenAI client with deployment %s", self.model)
        except ImportError:
            raise ImportError("OpenAI library not installed. Run: pip install openai")
    
    def generate(self, messages: list, **kwargs) -> str:
        """
        Generate text from the LLM with retry logic and metrics tracking.
        
        Args:
            messages: List of message dictionaries
            **kwargs: Additional configuration for the call
            
        Returns:
            Generated text response
            
        Raises:
            Exception: If LLM call fails after all retries
        """
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                return self._generate_with_metrics(messages, **kwargs)
            except Exception as e:
                last_error = e
                logger.warning("LLM call attempt %d/%d failed: %s", attempt + 1, self.max_retries, str(e))
                if attempt < self.max_retries - 1:
                    time.sleep(1 * (attempt + 1))  # Exponential backoff
        
        logger.error("LLM generation failed after %d attempts: %s", self.max_retries, str(last_error))
        raise Exception(f"Failed to generate response from {self.provider} after {self.max_retries} attempts: {str(last_error)}")
    
    def _generate_with_metrics(self, messages: list, **kwargs) -> str:
        """Generate text and track metrics."""
        start_time = time.time()
        
        if self.provider == "anthropic":
            result = self._call_anthropic(messages, **kwargs)
        elif self.provider == "azure_openai":
            result = self._call_azure_openai(messages, **kwargs)
        else:
            raise ValueError(f"Unsupported provider: {self.provider}")
        
        latency = time.time() - start_time
        
        # Track metrics
        self.metrics.record_call(
            input_tokens=result.get("input_tokens", 0),
            output_tokens=result.get("output_tokens", 0),
            model=self.model,
            latency=latency
        )
        
        return result["text"]
    
    def _call_anthropic(self, messages: list, **kwargs) -> Dict[str, Any]:
        """Call Anthropic API and return response with token counts."""
        # Extract system message if present in messages
        system_message = None
        filtered_messages = []
        
        for msg in messages:
            if msg["role"] == "system":
                system_message = msg["content"]
            else:
                filtered_messages.append(msg)
        
        # Build params for Anthropic API
        # Note: temperature, top_p, top_k were removed in Anthropic SDK 1.0
        call_params = {
            'model': self.model,
            'messages': filtered_messages,
            'max_tokens': kwargs.get('max_tokens', get_anthropic_max_tokens()),
            'timeout': self.timeout
        }
        
        # Add system parameter at top level (Anthropic requirement)
        if system_message is not None:
            call_params['system'] = system_message
        
        response = self.client.messages.create(**call_params)
        
        return {
            "text": response.content[0].text,
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens
        }
    
    def _call_azure_openai(self, messages: list, **kwargs) -> Dict[str, Any]:
        """Call Azure OpenAI API and return response with token counts."""
        azure_kwargs = kwargs.copy()
        azure_kwargs.setdefault('max_tokens', get_azure_openai_max_tokens())
        azure_kwargs.setdefault('temperature', get_azure_openai_temperature())
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            **azure_kwargs
        )
        
        return {
            "text": response.choices[0].message.content,
            "input_tokens": response.usage.prompt_tokens,
            "output_tokens": response.usage.completion_tokens
        }
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of all LLM call metrics."""
        summary = self.metrics.get_summary()
        logger.info("LLM Metrics Summary | Calls: %d | Total Tokens: %d | Total Cost: $%.6f | Avg Latency: %.2fs",
                   summary["total_calls"], summary["total_tokens"],
                   summary["estimated_total_cost_usd"], summary["average_latency_seconds"])
        return summary
