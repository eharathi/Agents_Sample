"""
Guardrails Module - Implements safety constraints for the workflow agent
"""

from typing import List, Tuple
from state import (
    OnboardingWorkflowState,
    EmployeeInfo,
    EquipmentItem,
    SoftwareAccess,
    InductionSession,
    ApprovalStatus,
    WorkflowStatus
)
import logging

logger = logging.getLogger(__name__)


class GuardrailViolation(Exception):
    """Exception raised when a guardrail is violated."""
    pass


def validate_employee_exists(state: OnboardingWorkflowState) -> Tuple[bool, str]:
    """
    Guardrail 1: Ensure employee information is sufficient to proceed.
    
    Args:
        state: Current workflow state
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    emp = state.employee
    if not emp.name:
        return False, "Employee name is required"
    if not emp.employee_id:
        return False, "Employee ID is required"
    if not emp.department:
        return False, "Employee department is required"
    return True, ""


def guardrail_no_write_without_approval(state: OnboardingWorkflowState) -> Tuple[bool, str]:
    """
    Guardrail 2: Prevent write operations without explicit human approval.
    
    Args:
        state: Current workflow state
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if state.approval_status != ApprovalStatus.APPROVED:
        return False, "Write operations (equipment reservation, induction scheduling, etc.) require explicit human approval"
    return True, ""


def guardrail_validate_equipment_requested(state: OnboardingWorkflowState) -> Tuple[bool, str]:
    """
    Guardrail 3: Ensure equipment requests are valid and available.
    
    Args:
        state: Current workflow state
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    for equipment in state.equipment_needed:
        if not equipment.item_type:
            return False, f"Equipment type is required for {equipment.description}"
        if equipment.item_type.lower() not in ["laptop", "monitor", "keyboard", "mouse", "security_token", "docking_station"]:
            return False, f"Unsupported equipment type: {equipment.item_type}"
    return True, ""


def guardrail_prevent_duplicate_actions(state: OnboardingWorkflowState, action_description: str) -> Tuple[bool, str]:
    """
    Guardrail 4: Prevent executing the same action twice (idempotency).
    
    Args:
        state: Current workflow state
        action_description: Description of the action to check
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if action_description in state.executed_actions:
        return False, f"Action already executed: {action_description}"
    return True, ""


def validate_workflow_can_proceed(state: OnboardingWorkflowState) -> List[str]:
    """
    Validate that the workflow can proceed to the next step.
    
    Args:
        state: Current workflow state
        
    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    
    # Run all guardrails/validations
    is_valid, error_msg = validate_employee_exists(state)
    if not is_valid:
        errors.append(error_msg)
    
    is_valid, error_msg = guardrail_validate_equipment_requested(state)
    if not is_valid:
        errors.append(error_msg)
    
    # Only check write operations guardrail if we're in a phase where write operations would occur
    # Don't check during initial validation, information gathering, or awaiting approval
    if state.status not in [
        WorkflowStatus.COLLECTING_INFO,
        WorkflowStatus.VALIDATING_INFO,
        WorkflowStatus.REQUIRES_USER_INPUT,
        WorkflowStatus.AWAITING_APPROVAL,
    ]:
        is_valid, error_msg = guardrail_no_write_without_approval(state)
        if not is_valid:
            errors.append(error_msg)
    
    return errors


def get_ready_for_approval_actions(state: OnboardingWorkflowState) -> List[str]:
    """
    Get list of actions that are ready for human approval.
    
    Args:
        state: Current workflow state
        
    Returns:
        List of action descriptions ready for approval
    """
    actions = []
    
    # Equipment reservations
    for equipment in state.equipment_needed:
        if equipment.is_available and equipment.item_type:
            actions.append(f"Reserve {equipment.item_type} ({equipment.description}) for {state.employee.name}")
    
    # Software access grants
    for access in state.software_access_needed:
        actions.append(f"Grant {access.access_level} access to {access.name} for {state.employee.name}")
    
    # Induction scheduling
    if state.induction_session:
        actions.append(f"Schedule induction: {state.induction_session.title} at {state.induction_session.scheduled_time}")
    
    # Checklist creation
    if state.onboarding_checklist:
        actions.append(f"Create onboarding checklist with {len(state.onboarding_checklist)} items")
    
    # Welcome email generation
    if state.welcome_email_draft:
        actions.append(f"Generate welcome email for {state.employee.name}")
    
    return actions