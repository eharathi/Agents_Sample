"""
Enterprise Workflow Agent - LLM-driven orchestration of the employee onboarding workflow
"""

from typing import Optional, List, Dict, Any
import logging
import json
import re

from state import (
    OnboardingWorkflowState,
    EmployeeInfo,
    WorkflowStatus,
    ApprovalStatus,
    EquipmentItem,
    InductionSession,
)
from tools.employee import get_employee
from tools.equipment import check_equipment_availability, reserve_equipment
from tools.access import get_required_access
from tools.calendar import find_induction_slots, schedule_induction
from tools.checklist import create_onboarding_checklist
from tools.email import generate_welcome_email
from tool_registry import tool_registry
from guardrails import (
    validate_employee_exists,
    guardrail_no_write_without_approval,
    guardrail_validate_equipment_requested,
    guardrail_prevent_duplicate_actions,
    validate_workflow_can_proceed,
    get_ready_for_approval_actions,
)
from llm_client import LLMClient
from llm_config import get_max_agent_iterations

logger = logging.getLogger(__name__)

# Alias for convenience
WS = WorkflowStatus


class EnterpriseWorkflowAgent:
    """Enterprise workflow agent for employee onboarding driven by LLM decisions."""
    
    def __init__(self, llm_client: LLMClient):
        """Initialize the workflow agent with an LLM client."""
        self.llm_client = llm_client
        self.state: Optional[OnboardingWorkflowState] = None
        self.max_iterations = get_max_agent_iterations()
        self.iteration_count = 0
    
    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    
    def start_workflow(self, employee_id: Optional[str] = None) -> OnboardingWorkflowState:
        """Start a new onboarding workflow, optionally with an employee ID."""
        self.state = OnboardingWorkflowState()
        self.iteration_count = 0
        
        if employee_id:
            try:
                employee = get_employee(employee_id)
                self.state.employee = EmployeeInfo(
                    employee_id=employee.employee_id,
                    name=employee.name,
                    department=employee.department,
                    role=employee.role,
                    manager=employee.manager,
                    location=employee.location,
                    start_date=employee.start_date,
                )
                self.state.add_to_conversation("system", f"Workflow started for employee: {employee.name} ({employee.employee_id})")
            except ValueError as e:
                self.state.add_to_conversation("system", f"Workflow started but employee '{employee_id}' not found: {e}")
                self.state.missing_info_fields = ["employee_id", "name", "department", "role"]
        else:
            self.state.add_to_conversation("system", "Workflow started. No employee ID provided yet.")
            self.state.missing_info_fields = ["employee_id", "name", "department", "role"]
        
        self.state.update_status(WS.COLLECTING_INFO)
        logger.info(f"Started workflow (employee_id={employee_id})")
        return self.state
    
    def process_user_input(self, user_input: str) -> str:
        """Process user input and advance the workflow via the LLM."""
        if self.state is None:
            return "Error: Workflow not started. Please call start_workflow() first."
        
        # Record user input in conversation history
        if user_input.strip():
            self.state.add_to_conversation("user", user_input.strip())
        
        # Check for approval / rejection commands
        user_lower = user_input.strip().lower()
        if user_lower in ("approve", "approved", "y", "yes"):
            return self._handle_approval(True)
        if user_lower in ("reject", "rejected", "n", "no"):
            return self._handle_approval(False)
        if user_lower.startswith(("exit", "quit")):
            self.state.set_error("Workflow terminated by user")
            return "Workflow terminated."
        
        # If we were waiting for a specific answer, store it
        if self.state.pending_question:
            self._store_answer(user_input.strip())
            self.state.set_pending_question(None)
        
        # Run the LLM-driven loop
        return self._run_agent_loop()
    
    def is_workflow_complete(self) -> bool:
        """Check if the workflow is complete."""
        if self.state is None:
            return False
        return self.state.status in [WS.COMPLETED, WS.FAILED]
    
    def get_workflow_state(self) -> Optional[OnboardingWorkflowState]:
        """Get the current workflow state."""
        return self.state
    
    def get_audit_trail(self) -> str:
        """Get the formatted audit trail."""
        if self.state is None:
            return "No workflow state available."
        
        lines = []
        lines.append("=" * 40)
        lines.append("AUDIT TRAIL")
        lines.append("=" * 40)
        
        for entry in self.state.conversation_history:
            role = entry.get("role", "unknown")
            content = entry.get("content", "")
            timestamp = entry.get("timestamp", "")
            lines.append(f"[{timestamp}] {role}: {content}")
        
        lines.append("=" * 40)
        lines.append(f"Final Status: {self.state.status.value}")
        lines.append(f"Approval Status: {self.state.approval_status.value}")
        lines.append(f"Executed Actions: {len(self.state.executed_actions)}")
        lines.append(f"Failed Actions: {len(self.state.failed_actions)}")
        lines.append(f"LLM Calls: {self.state.llm_call_count}")
        lines.append(f"Tool Calls: {self.state.tool_call_count}")
        lines.append("=" * 40)
        
        return "\n".join(lines)
    
    # ------------------------------------------------------------------
    # LLM-driven agent loop
    # ------------------------------------------------------------------
    
    def _run_agent_loop(self) -> str:
        """Run the LLM-driven agent loop until the workflow reaches a terminal state."""
        while not self.is_workflow_complete() and self.iteration_count < self.max_iterations:
            self.iteration_count += 1
            
            # Build structured context for the LLM
            messages = self._build_context()
            
            # Call the LLM
            try:
                self.state.llm_call_count += 1
                llm_response = self.llm_client.generate(messages, max_tokens=1024)
            except Exception as e:
                logger.error("LLM call failed: %s", e)
                self.state.set_error(f"LLM call failed: {e}")
                return f"Error: LLM call failed - {e}"
            
            # Record the LLM response
            self.state.add_to_conversation("assistant", llm_response)
            
            # Parse the LLM response to determine the next action
            action = self._parse_llm_response(llm_response)
            
            if action["type"] == "respond":
                # The LLM wants to say something to the user
                return action["message"]
            
            elif action["type"] == "tool_call":
                # Execute the requested tool
                tool_name = action.get("tool") or action.get("tool_name")
                arguments = action.get("arguments", {})
                result = self._execute_tool(tool_name, arguments)
                if result.get("error"):
                    self.state.add_to_conversation("system", f"Tool error: {result['error']}")
                    # Let the LLM know about the failure on the next iteration
                    continue
                else:
                    self.state.add_to_conversation("system", f"Tool result: {json.dumps(result['result'], default=str)}")
                    # Continue the loop to let the LLM decide the next step
                    continue
            
            elif action["type"] == "request_approval":
                # Check if approval is already granted (e.g., from a previous user input)
                if self.state.approval_status == ApprovalStatus.APPROVED:
                    self.state.update_status(WS.EXECUTING)
                    self.state.add_to_conversation("system", "Approval granted. Executing onboarding actions.")
                    return self._execute_approved_actions()
                # Present actions and wait for user approval
                return self._present_approval_request()
            
            elif action["type"] == "complete":
                # Workflow is done
                self.state.update_status(WS.COMPLETED)
                self.state.add_to_conversation("system", "Workflow completed successfully.")
                return action.get("message", "Workflow completed successfully.")
            
            elif action["type"] == "ask_user":
                # The LLM wants to ask the user a question
                self.state.set_pending_question(action["question"])
                self.state.update_status(WS.REQUIRES_USER_INPUT)
                return action["question"]
            
            else:
                # Unknown action - ask the LLM to clarify
                self.state.add_to_conversation("system", f"Unknown action type: {action['type']}")
                continue
        
        if self.iteration_count >= self.max_iterations:
            self.state.set_error(f"Maximum agent iterations ({self.max_iterations}) exceeded")
            return f"Error: Maximum iterations ({self.max_iterations}) exceeded. Workflow terminated."
        
        return "Workflow is complete."
    
    def _build_context(self) -> List[Dict[str, str]]:
        """Build the structured context (messages) to send to the LLM."""
        system_prompt = self._get_system_prompt()
        
        messages = [{"role": "system", "content": system_prompt}]
        
        # Add conversation history (limited to last 10 turns to manage context size)
        history = self.state.conversation_history[-10:]
        for entry in history:
            role = entry.get("role", "user")
            content = entry.get("content", "")
            # Map internal roles to LLM roles
            if role == "system":
                role = "user"  # Anthropic doesn't allow system in messages
            messages.append({"role": role, "content": content})
        
        # Add current workflow state summary
        state_summary = self._get_state_summary()
        messages.append({"role": "user", "content": f"Current workflow state:\n{state_summary}\n\nWhat should we do next?"})
        
        return messages
    
    def _get_system_prompt(self) -> str:
        """Get the system prompt that instructs the LLM how to behave."""
        return """You are an enterprise employee onboarding assistant. Your job is to help onboard new employees by:

1. Collecting employee information (employee_id, name, department, role)
2. Validating that information
3. Determining equipment, software access, and induction requirements
4. Building an onboarding plan
5. Requesting human approval before executing write operations
6. Executing approved actions
7. Generating a checklist and welcome email

You have access to the following tools:
- get_employee(employee_id): Look up employee info
- check_equipment_availability(equipment_type): Check equipment stock
- get_required_access(department, role): Get required software access
- find_induction_slots(department): Find available induction sessions
- reserve_equipment(item_id, employee_id): Reserve equipment (WRITE - requires approval)
- schedule_induction(session_id, employee_id, employee_name): Schedule induction (WRITE - requires approval)
- create_onboarding_checklist(...): Create checklist (WRITE - requires approval)
- generate_welcome_email(...): Generate welcome email draft (WRITE - requires approval)

IMPORTANT RULES:
- NEVER execute write operations without explicit human approval.
- If required information is missing, ask the user for it.
- If a tool fails, report the failure and suggest alternatives.
- When the workflow is complete, say "WORKFLOW COMPLETE".
- When you need approval, say "APPROVAL REQUIRED" and list the actions.
- When you want to use a tool, respond with ONLY a JSON block in this format:
  {"action": "tool_call", "tool": "tool_name", "arguments": {"arg1": "value1"}}
- When you want to respond to the user, respond with ONLY a JSON block:
  {"action": "respond", "message": "your message here"}
- When you want to ask the user a question, respond with ONLY a JSON block:
  {"action": "ask_user", "question": "your question here"}
- When the workflow is complete, respond with ONLY a JSON block:
  {"action": "complete", "message": "summary here"}
- When you need approval, respond with ONLY a JSON block:
  {"action": "request_approval", "actions": ["action1", "action2"]}
"""
    
    def _get_state_summary(self) -> str:
        """Get a concise summary of the current workflow state."""
        s = self.state
        lines = [
            f"Status: {s.status.value}",
            f"Approval: {s.approval_status.value}",
        ]
        
        if s.employee.employee_id:
            lines.append(f"Employee: {s.employee.name} ({s.employee.employee_id})")
            lines.append(f"Department: {s.employee.department}, Role: {s.employee.role}")
        else:
            missing = s.get_missing_info()
            if missing:
                lines.append(f"Missing info: {', '.join(missing)}")
        
        if s.equipment_needed:
            lines.append(f"Equipment: {[e.item_type for e in s.equipment_needed]}")
        if s.software_access_needed:
            lines.append(f"Access: {[a.name for a in s.software_access_needed]}")
        if s.induction_session:
            lines.append(f"Induction: {s.induction_session.title}")
        
        if s.executed_actions:
            lines.append(f"Executed: {len(s.executed_actions)} actions")
        if s.failed_actions:
            lines.append(f"Failed: {s.failed_actions}")
        
        return "\n".join(lines)
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """Parse the LLM response to determine the next action."""
        # Try to extract JSON from the response - look for the outermost braces
        json_match = re.search(r'\{.*"action".*\}', response, re.DOTALL)
        if json_match:
            try:
                action = json.loads(json_match.group())
                # Normalize the action key to "type"
                if "action" in action and "type" not in action:
                    action["type"] = action.pop("action")
                return action
            except json.JSONDecodeError:
                pass
        
        # Fallback: check for keywords
        response_lower = response.lower()
        
        if "workflow complete" in response_lower or "onboarding complete" in response_lower:
            return {"type": "complete", "message": response}
        
        if "approval required" in response_lower or "approve" in response_lower:
            return {"type": "request_approval"}
        
        if "?" in response and len(response) < 200:
            return {"type": "ask_user", "question": response}
        
        # Default: treat as a response to the user
        return {"type": "respond", "message": response}
    
    # ------------------------------------------------------------------
    # Tool execution
    # ------------------------------------------------------------------
    
    def _execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool by name with the given arguments."""
        self.state.tool_call_count += 1
        
        # Check if tool exists in registry
        if not tool_registry.tool_exists(tool_name):
            return {"error": f"Tool '{tool_name}' is not registered."}
        
        tool_def = tool_registry.get_tool_definition(tool_name)
        tool_func = tool_registry.get_tool(tool_name)
        
        # Guardrail: check if this is a write operation and if approval is granted
        if tool_def.is_write_operation:
            is_valid, error_msg = guardrail_no_write_without_approval(self.state)
            if not is_valid:
                return {"error": f"Write operation '{tool_name}' blocked: {error_msg}"}
        
        # Guardrail: prevent duplicate actions
        action_desc = f"{tool_name}({', '.join(f'{k}={v}' for k, v in arguments.items())})"
        is_valid, error_msg = guardrail_prevent_duplicate_actions(self.state, action_desc)
        if not is_valid:
            return {"error": f"Duplicate action blocked: {error_msg}"}
        
        try:
            # Call the tool
            result = tool_func(**arguments)
            
            # Convert Pydantic models to dicts for JSON serialization in conversation history
            serializable_result = result
            if hasattr(result, 'model_dump'):
                serializable_result = result.model_dump()
            elif isinstance(result, list) and result and hasattr(result[0], 'model_dump'):
                serializable_result = [item.model_dump() for item in result]
            
            # Update state based on tool results
            self._update_state_from_tool_result(tool_name, result, arguments)
            
            return {"result": serializable_result}
        except Exception as e:
            logger.error("Tool execution failed: %s", e)
            return {"error": str(e)}
    
    def _update_state_from_tool_result(self, tool_name: str, result: Any, arguments: Dict[str, Any]) -> None:
        """Update workflow state based on the result of a tool execution."""
        if tool_name == "get_employee":
            if hasattr(result, 'employee_id'):
                self.state.employee = EmployeeInfo(
                    employee_id=result.employee_id,
                    name=result.name,
                    department=result.department,
                    role=result.role,
                    manager=result.manager,
                    location=result.location,
                    start_date=result.start_date,
                )
                self.state.update_status(WS.VALIDATING_INFO)
        
        elif tool_name == "check_equipment_availability":
            if isinstance(result, list):
                for item in result:
                    # Check if this equipment type is already tracked
                    existing = [e for e in self.state.equipment_needed if e.item_type == item.item_type]
                    if not existing:
                        self.state.equipment_needed.append(EquipmentItem(
                            item_id=item.item_id,
                            item_type=item.item_type,
                            description=item.description,
                            is_available=item.is_available,
                            reserved_for=item.reserved_for,
                        ))
        
        elif tool_name == "get_required_access":
            if isinstance(result, list):
                # Convert SoftwareAccess objects to state SoftwareAccess if needed
                from state import SoftwareAccess
                access_list = []
                for item in result:
                    if hasattr(item, 'name'):
                        access_list.append(SoftwareAccess(
                            name=item.name,
                            access_level=item.access_level,
                            justification=item.justification
                        ))
                    else:
                        access_list.append(item)
                self.state.software_access_needed = access_list
        
        elif tool_name == "find_induction_slots":
            if isinstance(result, list) and result:
                first = result[0]
                self.state.induction_session = InductionSession(
                    session_id=first.session_id,
                    title=first.title,
                    scheduled_time=first.scheduled_time,
                    duration_minutes=first.duration_minutes,
                    location=first.location,
                    instructor=first.instructor,
                )
                self.state.update_status(WS.DETERMINING_REQUIREMENTS)
        
        elif tool_name == "create_onboarding_checklist":
            if isinstance(result, list):
                self.state.onboarding_checklist = result
        
        elif tool_name == "generate_welcome_email":
            if isinstance(result, str):
                self.state.welcome_email_draft = result
        
        elif tool_name == "reserve_equipment":
            self.state.executed_actions.append(f"Reserve {arguments.get('item_id')}")
        
        elif tool_name == "schedule_induction":
            self.state.executed_actions.append(f"Schedule induction {arguments.get('session_id')}")
    
    # ------------------------------------------------------------------
    # Approval handling
    # ------------------------------------------------------------------
    
    def _present_approval_request(self) -> str:
        """Present the proposed actions to the user for approval."""
        self.state.update_status(WS.AWAITING_APPROVAL)
        self.state.approval_requested_at = self.state.updated_at
        
        ready_actions = get_ready_for_approval_actions(self.state)
        if not ready_actions:
            return "No actions require approval. Proceeding..."
        
        actions_text = "\n".join([f"  {i+1}. {action}" for i, action in enumerate(ready_actions)])
        return (f"APPROVAL REQUIRED\n"
                f"Employee: {self.state.employee.name} ({self.state.employee.employee_id})\n"
                f"Department: {self.state.employee.department}\n\n"
                f"Proposed actions:\n{actions_text}\n\n"
                f"Approve these actions? [y/n]")
    
    def _handle_approval(self, approved: bool) -> str:
        """Handle user approval or rejection."""
        if approved:
            self.state.approval_status = ApprovalStatus.APPROVED
            self.state.approval_responded_at = self.state.updated_at
            
            if self.state.status == WS.AWAITING_APPROVAL:
                self.state.update_status(WS.EXECUTING)
                self.state.add_to_conversation("system", "Human approval granted. Executing onboarding actions.")
                return self._execute_approved_actions()
            else:
                return "Approval granted. Your response has been recorded."
        else:
            self.state.approval_status = ApprovalStatus.REJECTED
            self.state.approval_responded_at = self.state.updated_at
            self.state.set_error("Workflow rejected by user")
            return "Approval rejected. Workflow terminated as requested."
    
    def _execute_approved_actions(self) -> str:
        """Execute all approved write actions."""
        # Execute equipment reservations
        for equipment in self.state.equipment_needed:
            if equipment.is_available:
                try:
                    reserve_equipment(equipment.item_id, self.state.employee.employee_id)
                    self.state.executed_actions.append(f"Reserve {equipment.item_id}")
                except ValueError as e:
                    self.state.failed_actions.append(f"Reserve {equipment.item_id}: {e}")
        
        # Execute software access grants
        for access in self.state.software_access_needed:
            self.state.executed_actions.append(f"Grant {access.access_level} access to {access.name}")
        
        # Execute induction scheduling
        if self.state.induction_session:
            try:
                schedule_induction(
                    session_id=self.state.induction_session.session_id,
                    employee_id=self.state.employee.employee_id,
                    employee_name=self.state.employee.name,
                )
                self.state.executed_actions.append(f"Schedule induction: {self.state.induction_session.session_id}")
            except ValueError as e:
                self.state.failed_actions.append(f"Schedule induction: {e}")
        
        # Generate checklist and email
        self._generate_artifacts()
        
        # Move to completed
        self.state.update_status(WS.COMPLETED)
        self.state.add_to_conversation("system", "All onboarding actions executed. Workflow complete.")
        
        return (f"Onboarding workflow completed!\n"
                f"Employee: {self.state.employee.name} ({self.state.employee.employee_id})\n"
                f"Status: {self.state.status.value}\n"
                f"Checklist items: {len(self.state.onboarding_checklist)}\n"
                f"Executed actions: {', '.join(self.state.executed_actions) if self.state.executed_actions else 'None'}\n"
                f"Welcome email draft: {'Available' if self.state.welcome_email_draft else 'Not generated'}")
    
    def _generate_artifacts(self) -> None:
        """Generate onboarding checklist and welcome email."""
        equipment_needed = [
            {"item_type": e.item_type, "description": e.description, "item_id": e.item_id}
            for e in self.state.equipment_needed
        ]
        
        software_access_needed = [
            {"name": a.name, "access_level": a.access_level, "justification": a.justification}
            for a in self.state.software_access_needed
        ]
        
        induction_session_dict = None
        if self.state.induction_session:
            induction_session_dict = {
                "session_id": self.state.induction_session.session_id,
                "title": self.state.induction_session.title,
                "scheduled_time": self.state.induction_session.scheduled_time,
                "duration_minutes": self.state.induction_session.duration_minutes,
                "location": self.state.induction_session.location,
                "instructor": self.state.induction_session.instructor,
            }
        
        self.state.onboarding_checklist = create_onboarding_checklist(
            employee_name=self.state.employee.name,
            department=self.state.employee.department,
            role=self.state.employee.role,
            equipment_needed=equipment_needed,
            software_access_needed=software_access_needed,
            induction_session=induction_session_dict,
        )
        
        self.state.welcome_email_draft = generate_welcome_email(
            employee_name=self.state.employee.name,
            department=self.state.employee.department or "",
            role=self.state.employee.role or "",
            manager_name=self.state.employee.manager or "Manager",
            start_date=self.state.employee.start_date or "2026-10-02",
            equipment_list=equipment_needed,
            access_list=software_access_needed,
            induction_session={
                "title": self.state.induction_session.title if self.state.induction_session else "New Employee Orientation",
                "scheduled_time": self.state.induction_session.scheduled_time if self.state.induction_session else "TBD",
            } if self.state.induction_session else None,
        )
    
    # ------------------------------------------------------------------
    # Interactive Q&A
    # ------------------------------------------------------------------
    
    def _store_answer(self, answer: str) -> None:
        """Store a user's answer to a pending question."""
        if not self.state.pending_question:
            return
        
        question = self.state.pending_question.lower()
        
        if "employee id" in question or "emp" in question:
            self.state.employee.employee_id = answer.strip().upper()
        elif "name" in question:
            self.state.employee.name = answer.strip()
        elif "department" in question:
            self.state.employee.department = answer.strip()
        elif "role" in question:
            self.state.employee.role = answer.strip()
        
        # Try to look up the employee if we now have an ID
        if self.state.employee.employee_id and not self.state.employee.name:
            try:
                emp = get_employee(self.state.employee.employee_id)
                self.state.employee.name = emp.name
                self.state.employee.department = emp.department
                self.state.employee.role = emp.role
                self.state.employee.manager = emp.manager
                self.state.employee.location = emp.location
                self.state.employee.start_date = emp.start_date
            except ValueError:
                pass  # Employee not found, will be handled by validation
        
        self.state.add_to_conversation("system", f"User provided: {answer}")
