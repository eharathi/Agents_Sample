"""
State Management Module - Handles workflow state for the Employee Onboarding Agent
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field


class WorkflowStatus(str, Enum):
    """Workflow status values."""
    INITIALIZED = "initialized"
    COLLECTING_INFO = "collecting_info"
    VALIDATING_INFO = "validating_info"
    DETERMINING_REQUIREMENTS = "determining_requirements"
    BUILDING_PLAN = "building_plan"
    AWAITING_APPROVAL = "awaiting_approval"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    REQUIRES_USER_INPUT = "requires_user_input"


class ApprovalStatus(str, Enum):
    """Approval status values."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class EmployeeInfo(BaseModel):
    """Employee information model."""
    employee_id: Optional[str] = Field(None, description="Employee ID")
    name: Optional[str] = Field(None, description="Employee full name")
    department: Optional[str] = Field(None, description="Department")
    role: Optional[str] = Field(None, description="Job role")
    manager: Optional[str] = Field(None, description="Manager name")
    location: Optional[str] = Field(None, description="Office location")
    start_date: Optional[str] = Field(None, description="Start date")


class EquipmentItem(BaseModel):
    """Equipment item model."""
    item_id: str = Field(..., description="Equipment identifier")
    item_type: str = Field(..., description="Type of equipment")
    description: str = Field(..., description="Equipment description")
    is_available: bool = Field(True, description="Whether equipment is available")
    reserved_for: Optional[str] = Field(None, description="Employee ID if reserved")


class SoftwareAccess(BaseModel):
    """Software/access requirement model."""
    name: str = Field(..., description="Software/system name")
    access_level: str = Field(..., description="Access level required")
    justification: str = Field(..., description="Why this access is needed")


class InductionSession(BaseModel):
    """Induction session model."""
    session_id: str = Field(..., description="Session identifier")
    title: str = Field(..., description="Session title")
    scheduled_time: str = Field(..., description="Scheduled time")
    duration_minutes: int = Field(..., description="Duration in minutes")
    location: str = Field(..., description="Location (virtual or physical)")
    instructor: str = Field(..., description="Instructor name")


class OnboardingChecklistItem(BaseModel):
    """Onboarding checklist item model."""
    item_id: str = Field(..., description="Checklist item identifier")
    description: str = Field(..., description="Task description")
    category: str = Field(..., description="Category (e.g., Equipment, Access, Training)")
    completed: bool = Field(False, description="Whether item is completed")
    due_date: Optional[str] = Field(None, description="Due date")


class OnboardingWorkflowState(BaseModel):
    """Complete workflow state for employee onboarding."""
    # Workflow metadata
    workflow_id: str = Field(default_factory=lambda: f"onboard_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    status: WorkflowStatus = Field(default=WorkflowStatus.INITIALIZED)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    
    # Employee information
    employee: EmployeeInfo = Field(default_factory=EmployeeInfo)
    
    # Determined requirements
    equipment_needed: List[EquipmentItem] = Field(default_factory=list)
    software_access_needed: List[SoftwareAccess] = Field(default_factory=list)
    induction_session: Optional[InductionSession] = Field(None)
    
    # Generated artifacts
    onboarding_checklist: List[OnboardingChecklistItem] = Field(default_factory=list)
    welcome_email_draft: Optional[str] = Field(None)
    
    # Approval and execution
    approval_status: ApprovalStatus = Field(default=ApprovalStatus.PENDING)
    approval_requested_at: Optional[datetime] = Field(None)
    approval_responded_at: Optional[datetime] = Field(None)
    
    # Execution tracking
    executed_actions: List[str] = Field(default_factory=list)
    failed_actions: List[str] = Field(default_factory=list)
    
    # Conversation memory
    conversation_history: List[Dict[str, str]] = Field(default_factory=list)
    
    # Error handling
    error_message: Optional[str] = Field(None)
    
    # LLM interaction tracking
    llm_call_count: int = Field(default=0)
    tool_call_count: int = Field(default=0)
    pending_question: Optional[str] = Field(None)
    missing_info_fields: List[str] = Field(default_factory=list)
    
    def add_to_conversation(self, role: str, content: str) -> None:
        """Add a message to conversation history."""
        self.conversation_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        self.updated_at = datetime.now()
    
    def update_status(self, new_status: WorkflowStatus) -> None:
        """Update workflow status."""
        self.status = new_status
        self.updated_at = datetime.now()
    
    def set_error(self, message: str) -> None:
        """Set error message and update status."""
        self.error_message = message
        self.update_status(WorkflowStatus.FAILED)
    
    def get_missing_info(self) -> List[str]:
        """Get list of missing required employee information fields."""
        missing = []
        if not self.employee.employee_id:
            missing.append("employee_id")
        if not self.employee.name:
            missing.append("name")
        if not self.employee.department:
            missing.append("department")
        if not self.employee.role:
            missing.append("role")
        return missing
    
    def set_pending_question(self, question: Optional[str]) -> None:
        """Set a question that the agent is waiting for the user to answer."""
        self.pending_question = question
        self.updated_at = datetime.now()