"""
Main entry point for the Enterprise Assistant
"""

import logging
import sys
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from llm_client import LLMClient
from agent import EnterpriseAssistantAgent

# Configure logging to file only (no console output)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('enterprise_agent.log'),
        logging.NullHandler()  # Prevents console output
    ]
)
logger = logging.getLogger(__name__)

console = Console()

def main():
    """Main entry point for the application."""
    console.print(Panel.fit("[bold blue]Enterprise Assistant with Tools[/bold blue]"))
    console.print("Enter your questions using natural language:")
    console.print("Examples:")
    console.print("  • What department does John Smith work in?")
    console.print("  • What is the status of INC-1003?")
    console.print("  • What is the remote-work policy?")
    console.print("  • What department does John Smith work in and what is the remote-work policy for that department?")
    console.print()
    
    try:
        # Initialize LLM client and agent
        llm_client = LLMClient()
        agent = EnterpriseAssistantAgent(llm_client)
        
        while True:
            # Get user input
            query = console.input("[bold yellow]Question:[/bold yellow] ")
            
            if not query.strip():
                console.print("[bold red]Error:[/bold red] Question cannot be empty.")
                continue
                
            if query.strip().lower() in ['quit', 'exit', 'q']:
                console.print("[bold green]Goodbye![/bold green]")
                break
            
            # Process the query
            console.print("[bold cyan]Thinking...[/bold cyan]")
            response = agent.process_query(query)
            
            # Display result
            console.print()
            console.print(Panel.fit(f"[bold green]Answer:[/bold green]\n{response}"))
            console.print()
            
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Operation cancelled by user.[/bold yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        logger.error("Application error: %s", str(e))
        sys.exit(1)

if __name__ == "__main__":
    main()