# Lab 2 — Give Your AI Agent Tools

This lab teaches you how to build an AI agent that can use Python tools to extend its capabilities beyond basic text generation.

## Duration
90–120 minutes

## Objectives
After completing this lab, you will be able to:
- Explain what tool calling is
- Understand why agents need tools
- Demonstrate how LLMs select tools
- Show how tool schemas work
- Explain how Python functions become agent tools
- Illustrate how tool results are returned to the LLM
- Demonstrate how the agent loop works

## Prerequisites
- Python 3.11
- Basic Python knowledge
- Basic REST/API knowledge
- Basic JSON understanding
- Basic Git knowledge
- Access to Claude or Azure OpenAI credentials

## Environment Setup
Create the virtual environment:

```bash
python3.11 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

## Environment Variables

Set these environment variables:
- `LLM_PROVIDER` = `anthropic` or `azure_openai` (default: anthropic)
- `ANTHROPIC_API_KEY` = Your Claude API key
- `ANTHROPIC_MODEL` = Model to use (default: claude-3-haiku-20240307)
- `AZURE_OPENAI_API_KEY` = Your Azure OpenAI API key
- `AZURE_OPENAI_ENDPOINT` = Your Azure OpenAI endpoint
- `AZURE_OPENAI_API_VERSION` = API version (default: 2024-02-15-preview)
- `AZURE_OPENAI_DEPLOYMENT` = Deployment name

## Installation
```bash
pip install -r requirements.txt
```

## Running the Lab
```bash
python main.py
```

## Exercises

### Exercise 1 — Create a Python Tool
Implement and test `get_employee()`

### Exercise 2 — Register the Tool
Add it to the tool registry and define its schema

### Exercise 3 — Let the LLM Select the Tool
Give the LLM access to the tool definition

### Exercise 4 — Execute the Tool
Implement LLM → tool call → Python function → result

### Exercise 5 — Add More Tools
Add policy search, ticket lookup, department information

### Exercise 6 — Multi-Tool Workflow
Handle a request requiring two tools

### Exercise 7 — Error Handling
Test nonexistent employee, ticket, invalid arguments, unknown tools

## Example Requests
```
What department does John Smith work in?
What is the status of INC-1003?
What is the remote-work policy?
What department does John Smith work in and what is the remote-work policy for that department?
```

## Troubleshooting
- Missing API key: Set the required environment variables
- Incorrect provider: Check LLM_PROVIDER value
- Authentication failure: Verify API keys and permissions
- Timeout: Check network connectivity and API limits