"""
Agent Module - Enhanced agent with tool calling capabilities
"""

import json
import logging
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
from llm_client import LLMClient
from tool_registry import tool_registry, ToolDefinition
from tools import get_employee, search_policy, get_ticket_status, get_department_information

logger = logging.getLogger(__name__)

class ToolCall(BaseModel):
    """Represents a tool call request from the LLM."""
    tool_name: str = Field(..., description="Name of the tool to call")
    arguments: Dict[str, Any] = Field(..., description="Arguments to pass to the tool")

class ToolResult(BaseModel):
    """Represents a tool result that can be returned to the LLM."""
    tool_call_id: str = Field(..., description="ID of the tool call")
    result: str = Field(..., description="Result from the tool execution")
    error: Optional[str] = Field(None, description="Error if tool execution failed")

class EnterpriseAssistantAgent:
    """An enterprise assistant that can use Python tools to enhance its capabilities."""
    
    # Define available tools and their schemas
    TOOLS = {
        "get_employee": ToolDefinition(
            name="get_employee",
            description="Retrieve employee information from the enterprise employee directory.",
            parameters={
                "type": "object",
                "properties": {
                    "employee_name": {
                        "type": "string",
                        "description": "Full name of the employee to look up"
                    }
                },
                "required": ["employee_name"]
            }
        ),
        "search_policy": ToolDefinition(
            name="search_policy",
            description="Search for policies that match a query.",
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (e.g., 'remote work', 'leave')"
                    }
                },
                "required": ["query"]
            }
        ),
        "get_ticket_status": ToolDefinition(
            name="get_ticket_status",
            description="Get status of a service desk ticket.",
            parameters={
                "type": "object",
                "properties": {
                    "ticket_id": {
                        "type": "string",
                        "description": "Ticket identifier (e.g., 'INC-1001')"
                    }
                },
                "required": ["ticket_id"]
            }
        ),
        "get_department_information": ToolDefinition(
            name="get_department_information",
            description="Get information about a department.",
            parameters={
                "type": "object",
                "properties": {
                    "department_name": {
                        "type": "string",
                        "description": "Name of the department to look up"
                    }
                },
                "required": ["department_name"]
            }
        )
    }
    
    def __init__(self, llm_client: LLMClient):
        """
        Initialize the agent with an LLM client.
        
        Args:
            llm_client: An instance of LLMClient to use for generating responses
        """
        self.llm_client = llm_client
        
        # Register all tools with the central registry from tools module
        from tools import TOOLS
        for tool_name, tool_definition in self.TOOLS.items():
            if tool_name in TOOLS:
                tool_func = TOOLS[tool_name]
                tool_registry.register_tool(tool_func, tool_definition)
            else:
                raise ValueError(f"Could not find tool function for {tool_name}")
        
        logger.info("EnterpriseAssistantAgent initialized with %d tools", len(self.TOOLS))
    
    def process_query(self, query: str) -> str:
        """
        Process a user query by potentially using tools.
        
        Args:
            query: User's natural language query
            
        Returns:
            Final answer after potentially using tools
        """
        logger.info("Processing query: %s", query)
        
        # Start with initial tool call decision prompt
        system_prompt = (
            "You are an enterprise assistant that can use internal tools to answer questions. "
            "When a question requires specific information, you should: \n\n"
            "1. Decide if you need to use a tool to get the information\n"
            "2. If you need a tool, format your response as a tool call\n"
            "3. If you don't need a tool, provide your final answer directly\n\n"
            "Available tools are:\n"
        )
        
        # Add tool definitions to the system prompt
        for tool_def in tool_registry.get_all_schemas():
            system_prompt += f"- {tool_def.name}: {tool_def.description}\n"
        
        system_prompt += "\nIf you use a tool, respond only with a tool call. "
        system_prompt += "The tool call must be in the format: {\"tool_name\": \"...\", \"arguments\": {...}}\n"
        system_prompt += "Do not add any additional explanation before or after the tool call.\n"
        system_prompt += "If you don't need to use a tool, respond with directly with your answer."

        user_prompt = (
            f"Answer the following question as accurately as possible: '{query}'\n\n"
            "If this requires information from internal systems, use one or more of your available tools. "
            "Only use tools that are explicitly available in the list above."
        )
        
        # Initial call to determine if we need to use tools
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Make the initial request to the LLM
        response_text = self.llm_client.generate(
            messages=messages,
            temperature=0.2,
            max_tokens=1024
        )
        
        # Check if the response is a tool call
        try:
            tool_call = self._parse_tool_call(response_text)
            if tool_call:
                logger.info("Tool call detected: %s", tool_call.tool_name)
                
                # Execute the tool
                tool_result = self._execute_tool(tool_call)
                
                # Use the result to provide a better final answer
                final_response = self._get_final_answer(query, tool_result)
                return final_response
            else:
                # No tool call needed, return the direct response
                return response_text.strip()
        except Exception as e:
            logger.error("Error processing tool call or response: %s", str(e))
            
            # Try to return a fallback answer
            if "No tool call detected" in str(e) or "Tool call" in str(e):
                # If the LLM returned text but no tool was parsed, just return that
                return response_text.strip()
            else:
                # Return error response
                return f"I encountered an error while processing your request: {str(e)}"
    
    def _parse_tool_call(self, response_text: str) -> Optional[ToolCall]:
        """
        Parse a tool call from the LLM response.
        
        Args:
            response_text: Raw response from LLM
            
        Returns:
            ToolCall object if found, None otherwise
            
        Raises:
            ValueError: If response isn't valid tool call JSON
        """
        # Strip whitespace and check if JSON object
        clean_text = response_text.strip()
        
        # Handle markdown code block if present
        if clean_text.startswith("```json"):
            # Extract JSON from markdown
            end_marker = clean_text.find("```", 7)
            if end_marker != -1:
                json_text = clean_text[7:end_marker].strip()
            else:
                json_text = clean_text[7:].strip()
        else:
            json_text = clean_text
            
        try:
            data = json.loads(json_text)
            
            # Check if it looks like a tool call
            if "tool_name" in data and "arguments" in data:
                logger.debug("Parsed tool call: %s", data)
                return ToolCall(**data)
            
        except json.JSONDecodeError:
            logger.debug("Response doesn't look like a JSON tool call: %s", response_text[:100])
            pass
            
        logger.debug("No tool call found in response: %s", response_text[:100])
        return None
    
    def _execute_tool(self, tool_call: ToolCall) -> str:
        """
        Execute a tool call and return the result.
        
        Args:
            tool_call: ToolCall object with tool name and arguments
            
        Returns:
            String representation of the tool result
        """
        logger.info("Executing tool: %s", tool_call.tool_name)
        
        # Validate tool exists
        if not tool_registry.tool_exists(tool_call.tool_name):
            raise ValueError(f"Unknown tool requested: {tool_call.tool_name}")
        
        # Get the tool function
        tool_func = tool_registry.get_tool(tool_call.tool_name)
        
        try:
            # Execute the tool with provided arguments
            logger.debug("Calling tool %s with args: %s", tool_call.tool_name, tool_call.arguments)
            result = tool_func(**tool_call.arguments)
            
            # Convert result to string for LLM consumption
            return str(result)
        except TypeError as e:
            # Handle case where argument names don't match function signature
            if "unexpected keyword argument" in str(e):
                logger.error("Tool argument mismatch for %s: %s", tool_call.tool_name, str(e))
                logger.error("Arguments received: %s", tool_call.arguments)
                # Try to map common argument name mismatches
                if tool_call.tool_name == "get_employee" and "name" in tool_call.arguments and "employee_name" not in tool_call.arguments:
                    logger.info("Attempting to fix argument name: 'name' -> 'employee_name'")
                    fixed_arguments = {"employee_name": tool_call.arguments["name"]}
                    result = tool_func(**fixed_arguments)
                    return str(result)
                elif tool_call.tool_name == "get_department_information" and "name" in tool_call.arguments and "department_name" not in tool_call.arguments:
                    logger.info("Attempting to fix argument name: 'name' -> 'department_name'")
                    fixed_arguments = {"department_name": tool_call.arguments["name"]}
                    result = tool_func(**fixed_arguments)
                    return str(result)
                elif tool_call.tool_name == "get_ticket_status" and "id" in tool_call.arguments and "ticket_id" not in tool_call.arguments:
                    logger.info("Attempting to fix argument name: 'id' -> 'ticket_id'")
                    fixed_arguments = {"ticket_id": tool_call.arguments["id"]}
                    result = tool_func(**fixed_arguments)
                    return str(result)
            raise e
            
        except Exception as e:
            # Return error as string that can be processed by LLM
            error_msg = f"Error executing tool {tool_call.tool_name}: {str(e)}"
            logger.error(error_msg)
            return error_msg
    
    def _get_final_answer(self, query: str, tool_result: str) -> str:
        """
        Get a final response after tool execution.
        
        Args:
            query: Original query
            tool_result: Result from the tool execution
            
        Returns:
            Final answer incorporating the tool result
        """
        logger.info("Generating final answer...")
        
        system_prompt = (
            "You are an enterprise assistant. Based on the tool result, "
            "provide a clear, helpful answer to the original question. "
            "Include the relevant information from the tool result."
        )
        
        user_prompt = (
            f"Original question: '{query}'\n\n"
            f"Tool result: {tool_result}\n\n"
            "Provide a clear, concise answer that integrates the tool result."
        )
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = self.llm_client.generate(
            messages=messages,
            temperature=0.2,
            max_tokens=1024
        )
        
        return response.strip()