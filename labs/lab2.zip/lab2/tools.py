"""
Enterprise Tools - Python functions that serve as enterprise tools for the agent
"""

import json
import logging
from typing import Dict, Any, Optional
from pathlib import Path
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Load data from JSON files
def _load_json_data(filename: str) -> list:
    """Load JSON data from data directory."""
    try:
        data_path = Path(__file__).parent / "data" / filename
        with open(data_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load data from {filename}: {e}")
        return []

# Load employees data on startup
EMPLOYEES_DATA = _load_json_data("employees.json")
POLICIES_DATA = _load_json_data("policies.json")
TICKETS_DATA = _load_json_data("tickets.json")
DEPARTMENTS_DATA = _load_json_data("departments.json")

class Employee(BaseModel):
    """Employee information model."""
    employee_id: str = Field(..., description="Unique employee identifier")
    name: str = Field(..., description="Employee name")
    department: str = Field(..., description="Department the employee works in")
    role: str = Field(..., description="Job role")
    location: str = Field(..., description="Office location")
    manager: str = Field(..., description="Direct manager name")
    employment_status: str = Field(..., description="Current employment status")

class Policy(BaseModel):
    """Policy information model."""
    policy_id: str = Field(..., description="Unique policy identifier")
    title: str = Field(..., description="Policy title")
    category: str = Field(..., description="Policy category")
    content: str = Field(..., description="Detailed policy content")
    effective_date: str = Field(..., description="Effective date of policy")

class Ticket(BaseModel):
    """Service ticket model."""
    ticket_id: str = Field(..., description="Ticket identifier")
    status: str = Field(..., description="Ticket status")
    priority: str = Field(..., description="Ticket priority")
    assigned_to: str = Field(..., description="Person assigned to the ticket")
    created_date: str = Field(..., description="Date the ticket was created")
    description: str = Field(..., description="Ticket description")

class Department(BaseModel):
    """Department information model."""
    department_name: str = Field(..., description="Name of the department")
    head: str = Field(..., description="Head of the department")
    budget: str = Field(..., description="Annual budget")
    team_size: int = Field(..., description="Number of people in the department")
    description: str = Field(..., description="Department description")


def get_employee(employee_name: str) -> Employee:
    """
    Retrieve employee information from the enterprise employee directory.
    
    Args:
        employee_name: Name of the employee to look up
        
    Returns:
        Employee information
        
    Raises:
        ValueError: If employee not found
    """
    logger.info(f"Searching for employee: {employee_name}")
    
    for emp in EMPLOYEES_DATA:
        if emp["name"].lower() == employee_name.lower():
            return Employee(**emp)
    
    raise ValueError(f"Employee '{employee_name}' not found in directory")


def search_policy(query: str) -> Policy:
    """
    Search for policies that match the query.
    
    Args:
        query: Search query (e.g., "remote work", "leave")
        
    Returns:
        Matching policy information
        
    Raises:
        ValueError: If no matching policy found
    """
    logger.info(f"Searching for policy matching: {query}")
    
    # Simple substring search
    for policy in POLICIES_DATA:
        if query.lower() in policy["title"].lower() or query.lower() in policy["content"].lower():
            return Policy(**policy)
    
    raise ValueError(f"No policy found matching '{query}'")


def get_ticket_status(ticket_id: str) -> Ticket:
    """
    Get status of a service desk ticket.
    
    Args:
        ticket_id: Ticket identifier (e.g., "INC-1001")
        
    Returns:
        Ticket information
        
    Raises:
        ValueError: If ticket not found
    """
    logger.info(f"Getting status for ticket: {ticket_id}")
    
    for ticket in TICKETS_DATA:
        if ticket["ticket_id"] == ticket_id.upper():
            return Ticket(**ticket)
    
    raise ValueError(f"Ticket '{ticket_id}' not found in service desk")


def get_department_information(department_name: str) -> Department:
    """
    Get information about a department.
    
    Args:
        department_name: Name of department
        
    Returns:
        Department information
        
    Raises:
        ValueError: If department not found
    """
    logger.info(f"Getting information for department: {department_name}")
    
    for dept in DEPARTMENTS_DATA:
        if dept["department_name"].lower() == department_name.lower():
            return Department(**dept)
    
    raise ValueError(f"Department '{department_name}' not found")


# Export all tool functions for registration
TOOLS = {
    "get_employee": get_employee,
    "search_policy": search_policy,
    "get_ticket_status": get_ticket_status,
    "get_department_information": get_department_information
}