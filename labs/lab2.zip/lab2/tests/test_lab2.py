"""
Test suite for the Enterprise Assistant Tools and Agent
"""

import unittest
from unittest.mock import Mock, patch
import json
import os
import sys

# Add the current directory to Python path to allow imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")


# Import our modules
from llm_config import validate_configuration
from tool_registry import tool_registry, ToolDefinition
from agent import EnterpriseAssistantAgent, ToolCall
from tools import get_employee, search_policy, get_ticket_status, get_department_information


class TestToolRegistry(unittest.TestCase):
    """Test tool registry functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Clear registry for clean tests
        tool_registry._tools.clear()
        tool_registry._schemas.clear()
    
    def test_register_tool(self):
        """Test registering a tool."""
        def dummy_tool():
            return "test"
        
        definition = ToolDefinition(
            name="test_tool",
            description="A test tool",
            parameters={}
        )
        
        tool_registry.register_tool(dummy_tool, definition)
        self.assertTrue(tool_registry.tool_exists("test_tool"))
        self.assertEqual(tool_registry.get_tool("test_tool"), dummy_tool)
        self.assertEqual(tool_registry.get_schema("test_tool"), definition)
    
    def test_get_nonexistent_tool(self):
        """Test getting a non-existent tool."""
        with self.assertRaises(KeyError):
            tool_registry.get_tool("nonexistent")
    
    def test_get_all_schemas(self):
        """Test getting all tool schemas."""
        # Clear any existing tools
        tool_registry._tools.clear()
        tool_registry._schemas.clear()
        
        # Register a tool
        def dummy_tool():
            return "test"
        
        definition = ToolDefinition(
            name="dummy_tool",
            description="A dummy tool",
            parameters={}
        )
        tool_registry.register_tool(dummy_tool, definition)
        
        schemas = tool_registry.get_all_schemas()
        self.assertEqual(len(schemas), 1)
        self.assertEqual(schemas[0].name, "dummy_tool")


class TestTools(unittest.TestCase):
    """Test individual tools."""
    
    def test_get_employee_found(self):
        """Test getting existing employee."""
        result = get_employee("John Smith")
        self.assertEqual(result.name, "John Smith")
        self.assertEqual(result.department, "Engineering")
    
    def test_get_employee_not_found(self):
        """Test getting non-existing employee."""
        with self.assertRaises(ValueError):
            get_employee("Non Existent Person")
    
    def test_search_policy_found(self):
        """Test searching for existing policy."""
        result = search_policy("remote work")
        self.assertEqual(result.title, "Remote Work Policy")
    
    def test_search_policy_not_found(self):
        """Test searching for non-existing policy."""
        with self.assertRaises(ValueError):
            search_policy("non-existent policy")
    
    def test_get_ticket_status_found(self):
        """Test getting existing ticket."""
        result = get_ticket_status("INC-1001")
        self.assertEqual(result.ticket_id, "INC-1001")
        self.assertEqual(result.status, "Open")
    
    def test_get_ticket_status_not_found(self):
        """Test getting non-existing ticket."""
        with self.assertRaises(ValueError):
            get_ticket_status("INC-9999")
    
    def test_get_department_information_found(self):
        """Test getting existing department."""
        result = get_department_information("Engineering")
        self.assertEqual(result.department_name, "Engineering")
        self.assertEqual(result.head, "Jane Doe")
    
    def test_get_department_information_not_found(self):
        """Test getting non-existing department."""
        with self.assertRaises(ValueError):
            get_department_information("Non Existent Dept")


class TestAgent(unittest.TestCase):
    """Test agent tool calling functionality.""" 
    
    def setUp(self):
        """Set up test fixtures."""
        # We'll use a mock LLM client for isolated testing
        self.mock_client = Mock()
        self.agent = EnterpriseAssistantAgent(self.mock_client)
    
    def test_parse_tool_call_valid(self):
        """Test parsing a valid tool call string."""
        tool_call_json = '{"tool_name": "get_employee", "arguments": {"employee_name": "John Smith"}}'
        tool_call = self.agent._parse_tool_call(tool_call_json)
        self.assertIsNotNone(tool_call)
        self.assertEqual(tool_call.tool_name, "get_employee")
        self.assertEqual(tool_call.arguments, {"employee_name": "John Smith"})
    
    def test_parse_tool_call_invalid(self):
        """Test parsing an invalid tool call string."""
        bad_json = '{"tool_name": "get_employee"'
        result = self.agent._parse_tool_call(bad_json)
        self.assertIsNone(result)
        
    def test_parse_tool_call_no_tool(self):
        """Test parsing normal text instead of tool call."""
        normal_text = "This is a regular response from the assistant."
        result = self.agent._parse_tool_call(normal_text)
        self.assertIsNone(result)


class TestLLMConfig(unittest.TestCase):
    """Test LLM configuration module."""
    
    def test_validate_configuration_anthropic_valid(self):
        """Test validation with valid Anthropic setup."""
        with patch.dict('os.environ', {
            'LLM_PROVIDER': 'anthropic',
            'ANTHROPIC_API_KEY': 'test-key',
            
        }):
            # Should not raise exception
            validate_configuration()
    
    def test_validate_configuration_anthropic_missing_key(self):
        """Test validation with missing Anthropic API key."""
        with patch.dict('os.environ', {
        'LLM_PROVIDER': 'anthropic'
        }, clear=True):
            with self.assertRaises(ValueError):
                validate_configuration()


if __name__ == '__main__':
    unittest.main()