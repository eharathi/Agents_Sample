"""
Tool Registry - Central registry for all available tools
"""

import json
import logging
from typing import Dict, Any, Callable, List
from pydantic import BaseModel, Field
from pathlib import Path

logger = logging.getLogger(__name__)

class ToolDefinition(BaseModel):
    """Schema definition for a tool."""
    name: str = Field(..., description="Unique tool identifier")
    description: str = Field(..., description="Human-readable description of what the tool does")
    parameters: Dict[str, Any] = Field(..., description="JSON schema defining tool parameters")

class ToolRegistry:
    """Central registry for managing tools and their schemas."""
    
    def __init__(self):
        """Initialize the tool registry."""
        self._tools: Dict[str, Callable] = {}
        self._schemas: Dict[str, ToolDefinition] = {}
        logger.info("Tool registry initialized")
    
    def register_tool(self, func: Callable, definition: ToolDefinition):
        """
        Register a tool with its schema.
        
        Args:
            func: The callable function
            definition: ToolDefinition with schema
        """
        tool_name = definition.name
        self._tools[tool_name] = func
        self._schemas[tool_name] = definition
        logger.info(f"Registered tool: {tool_name}")
    
    def get_tool(self, name: str) -> Callable:
        """
        Get a registered tool by name.
        
        Args:
            name: Name of the tool
            
        Returns:
            The tool function
            
        Raises:
            KeyError: If tool is not found
        """
        if name not in self._tools:
            raise KeyError(f"Tool '{name}' not registered")
        return self._tools[name]
    
    def get_schema(self, name: str) -> ToolDefinition:
        """
        Get the schema for a registered tool.
        
        Args:
            name: Name of the tool
            
        Returns:
            ToolDefinition schema
            
        Raises:
            KeyError: If tool is not found
        """
        if name not in self._schemas:
            raise KeyError(f"Tool schema for '{name}' not registered")
        return self._schemas[name]
    
    def get_all_schemas(self) -> List[ToolDefinition]:
        """
        Get schemas for all registered tools.
        
        Returns:
            List of ToolDefinition schemas
        """
        return list(self._schemas.values())
    
    def tool_exists(self, name: str) -> bool:
        """
        Check if a tool exists in the registry.
        
        Args:
            name: Name of the tool
            
        Returns:
            True if tool exists, False otherwise
        """
        return name in self._tools

# Create a global registry instance
tool_registry = ToolRegistry()